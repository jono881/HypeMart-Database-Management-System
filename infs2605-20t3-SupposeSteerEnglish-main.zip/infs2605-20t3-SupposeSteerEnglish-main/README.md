# infs2605-20t3-SupposeSteerEnglish
infs2605-20t3-SupposeSteerEnglish

username and password

User	1234

User1	1234

User2	1234

Employee1	1234

Employee2	1234





User has all permissions except to change the order status
The supplier has all permissions but cannot add a place order
When the user ID or password is wrong, the screen will report an error（please check you userid and password )
 
Each supplier can modify its own order status but cannot modify the order status of other suppliers. If you want to change the status of an order from another supplier, the screen will report an error.（your not the supplier of this order)

Everyone can see the order status in the Dashboard interface, and the percentage of order status can be seen through the pie chart.
By searching for keywords in dashboard and clicking Search, you can query the order you want to know.
 
User can add a new order. User can select the supplier of this order from the list of suppliers. After that, User can select the items that can be ordered next to it. Then, output the number of items you want in Quantity. Just press Enter. If the quantity column is empty, the item will not be ordered. User can click Add Order, and when order is added, the order will appear in Order List. In Order List, double-click an order to query the detail of this Order. To modify order, click Order once in the Order List, then select the supplier and quantity for this Order, and finally click Update Order to update the order. If you want to delete an order, click the order and click Delete Order; If you want to delete a supplier, click supplier and click Delete. See the instructional video for details
