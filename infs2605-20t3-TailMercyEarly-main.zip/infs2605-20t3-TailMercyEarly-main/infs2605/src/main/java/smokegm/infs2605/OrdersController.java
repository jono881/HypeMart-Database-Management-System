package smokegm.infs2605;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javafx.fxml.FXML;
import java.sql.*;
import javafx.beans.binding.Bindings;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.collections.*;
import javafx.scene.control.Button;
import javafx.scene.control.TableRow;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseButton;
import javafx.util.converter.IntegerStringConverter;
import java.util.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import javafx.collections.transformation.FilteredList;
import javafx.scene.control.ComboBox;
import javafx.scene.control.cell.ComboBoxTableCell;

public class OrdersController {
    @FXML
    TableView<Order> orders;
    @FXML
    TableColumn<Order, String> orderID;
    @FXML
    TableColumn<Order, String> productName;
    @FXML
    TableColumn<Order, String> supplierID;
    @FXML
    TableColumn<Order, Integer> quantity;
    @FXML
    TableColumn<Order, String> orderStatus;
    @FXML
    TableColumn<Order, String> orderTimeStamp;
    @FXML
    TableColumn<Order, String> editedBy;

    @FXML
    TextField orderIdText;

    @FXML
    TextField quantityText;

    @FXML
    Button addButton;
    
    @FXML
    Button modifyButton;

    @FXML
    Button deleteButton;
    
    @FXML
    ComboBox supplierListCombBox;
    
    @FXML
    ComboBox productListComboBox;
    
    @FXML
    ComboBox orderStatusComboBox;
    
    @FXML
    ComboBox searchComboBox;
    
    @FXML
    TextField searchTextField;

    OrderDatabase database = new OrderDatabase();
    
    private String loginUsername;
    private String oldID;

    //Initializes the Order Screen with default properties
    @FXML
    public void initialize() throws SQLException, IOException {
        //This chunk of code reads the name of the current user.
        File exists = new File("details.txt");
        if (exists.exists()) {
            FileReader userfr = new FileReader("details.txt");
            BufferedReader userbr = new BufferedReader(userfr);
            loginUsername = userbr.readLine();
            userbr.close();
        }
        orders.setEditable(true);
        orderID.setEditable(false);
        editChanged();

        ObservableList<Order> orderlist = FXCollections.observableArrayList();
        orderlist = database.getOrder();
        orders.setItems(orderlist);

        orderID.setCellValueFactory(new PropertyValueFactory<>("orderID"));
        productName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        supplierID.setCellValueFactory(new PropertyValueFactory<>("supplierID"));
        quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        orderStatus.setCellValueFactory(new PropertyValueFactory<>("orderStatus"));
        orderTimeStamp.setCellValueFactory(new PropertyValueFactory<>("orderTimeStamp"));
        editedBy.setCellValueFactory(new PropertyValueFactory<>("editedBy"));
        
        orderStatusComboBox.setVisible(false);
        deleteButton.disableProperty().bind(Bindings.isEmpty(orders.getSelectionModel().getSelectedItems()));
        mousePressed();
        getComboBox();
        getSupplierList();
        getProductList();
        getFilteredList();
    }


    @FXML
    private void switchToLogin() throws IOException {
        App.setRoot("login");
    }

    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("home");
    }

    @FXML
    private void switchToSuppliers() throws IOException {
        App.setRoot("suppliers");
    }

    @FXML
    private void switchToOrders() throws IOException {
        App.setRoot("orders");
    }

    @FXML
    private void switchToAbout() throws IOException {
        App.setRoot("about");
    }
    @FXML
    private void switchToMulti() throws IOException {
        App.setRoot("multiorders");
    }
    @FXML
    private void switchToProducts() throws IOException {
        App.setRoot("products");
    }

    @FXML
    private void switchToHelp() throws IOException {
        App.setRoot("help");
    }

    //Add Order Record to Order Database & TableView when addButton is clicked
    @FXML
    public void switchToAdd() throws IOException {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Orders.db")) {
            Date date = new Date();
            Timestamp ts = new Timestamp(date.getTime());
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");  
            String finalString = formatter.format(ts);
            String databaseUpdate = "INSERT INTO Orders (ORDERID,PRODUCTNAME,SUPPLIERID,QUANTITY,ORDERSTATUS,ORDERTIMESTAMP, EDITEDBY) VALUES(?,?,?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(databaseUpdate);
            pstmt.setString(1, orderIdText.getText());
            pstmt.setString(2, productListComboBox.getValue().toString());
            String raw = supplierListCombBox.getSelectionModel().getSelectedItem().toString();
            int end = raw.indexOf(".");
            String clean = supplierListCombBox.getSelectionModel().getSelectedItem().toString();
            if (end != -1) {
            clean = raw.substring(0, end);
            }
            pstmt.setString(3, clean);            
            pstmt.setInt(4, Integer.parseInt(quantityText.getText()));
            pstmt.setString(5, "Order Placed");
            pstmt.setString(6, finalString);
            pstmt.setString(7, loginUsername);
            pstmt.execute();
            initialize();
            conn.close();
            orderIdText.clear();
            productListComboBox.setValue("Select Product");
            supplierListCombBox.setValue("Select Supplier");
            quantityText.clear();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    //Retrieves details of the selected Row once left click is pressed on mouse
    @FXML
    public void mousePressed() {
        orders.setRowFactory(mousePress -> {
            TableRow<Order> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if(! row.isEmpty() && event.getButton()==MouseButton.PRIMARY && event.getClickCount() == 1) {
                    orderStatusComboBox.setVisible(true);
                    Order selectedOrder = orders.getSelectionModel().getSelectedItem();
                    orderIdText.setText(selectedOrder.getOrderID());
                    oldID = orderIdText.getText();
                    productListComboBox.setValue(String.valueOf(selectedOrder.getProductName()));
                    supplierListCombBox.setValue(String.valueOf(selectedOrder.getSupplierID()));
                    quantityText.setText(String.valueOf(selectedOrder.getQuantity()));
                    orderStatusComboBox.setValue(String.valueOf(selectedOrder.getOrderStatus()));
                    ObservableList<String> orderStatusList = FXCollections.observableArrayList("Order Placed", "Order Processing", "Order Cancelled", "Order Failed", "Order Packed", "Order Picked", "Order Dispatched", "Order Refunded");
                    orderStatus.setCellFactory(ComboBoxTableCell.forTableColumn(orderStatusList));
                } else{
                    orderIdText.clear();
                    productListComboBox.setValue("Select Product");
                    supplierListCombBox.setValue("Select Supplier");
                    quantityText.clear();
                    orderStatusComboBox.setVisible(false);
                }
            });
            return row;
        });
    }
    
    //Updates the Order Database with the new Order Record as per the user needs using the modifyButton
    @FXML
    public void switchToModify() throws IOException {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Orders.db")) {
            orderStatusComboBox.setVisible(true);
            PreparedStatement stmt = conn.prepareStatement("UPDATE Orders SET ORDERID = ?, PRODUCTNAME = ?, SUPPLIERID = ?, QUANTITY = ?, ORDERSTATUS = ?, ORDERTIMESTAMP = ?, EDITEDBY = ? WHERE ORDERID = ? ");
            stmt.setString(1, orderIdText.getText());
            stmt.setString(2, productListComboBox.getSelectionModel().getSelectedItem().toString());
            String raw = supplierListCombBox.getSelectionModel().getSelectedItem().toString();
            int end = raw.indexOf(".");
            String clean = supplierListCombBox.getSelectionModel().getSelectedItem().toString();
            if (end != -1) {
            clean = raw.substring(0, end);
            }
            stmt.setString(3, clean);
            stmt.setInt(4, Integer.parseInt(quantityText.getText()));
            stmt.setString(5, (String) orderStatusComboBox.getSelectionModel().getSelectedItem());
            stmt.setString(6,getTimeStamp());
            stmt.setString(8, oldID);
            stmt.setString(7, loginUsername);
            stmt.execute();
            initialize();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Remove Order Record FROM Order Database & TableView when deleteButton is clicked
    @FXML
    public void switchToDelete() throws IOException {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Orders.db")) {
            Order selectedOrder = orders.getSelectionModel().getSelectedItem();
            String orderID = selectedOrder.getOrderID();
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM Orders WHERE ORDERID = ? ");
            stmt.setString(1, orderID);
            stmt.execute();
            initialize();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Functionality to Edit Cell Values in TableView
    @FXML
    public void editChanged() {
        productName.setCellFactory(TextFieldTableCell.forTableColumn());

        productName.setOnEditCommit(event -> {
            Order order = event.getRowValue();
            order.setProductName(event.getNewValue());
            try {
                updateData("PRODUCTNAME", event.getNewValue(), order.getOrderID());
            } catch (IOException ex) {
            }
        });
        supplierID.setCellFactory(TextFieldTableCell.forTableColumn());

        supplierID.setOnEditCommit(event -> {
            Order order = event.getRowValue();
            order.setSupplierID(event.getNewValue());
            try {
                updateData("SUPPLIERID", event.getNewValue(), order.getOrderID());
            } catch (IOException ex) {
            }
        });
        quantity.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));

        quantity.setOnEditCommit(event -> {
            Order order = event.getRowValue();
            order.setQuantity(event.getNewValue());
            try {
                updateData("QUANTITY", event.getNewValue().toString(), order.getOrderID());
            } catch (IOException ex) {
            }
        });
        orderStatus.setCellFactory(TextFieldTableCell.forTableColumn());

        orderStatus.setOnEditCommit(event -> {
            Order order = event.getRowValue();
            order.setOrderStatus(event.getNewValue());
            try {
                updateData("ORDERSTATUS", event.getNewValue(), order.getOrderID());
            } catch (IOException ex) {
            }
        });
        orderTimeStamp.setCellFactory(TextFieldTableCell.forTableColumn());
        orderTimeStamp.setOnEditCommit(event -> {
            Order order = event.getRowValue();
            order.setOrderTimeStamp(event.getNewValue());
            try {
                updateData("ORDERTIMESTAMP", event.getNewValue(), order.getOrderID());
            } catch (IOException ex) {
            }
        });
        orderID.setCellFactory(TextFieldTableCell.forTableColumn());

        orderID.setOnEditCommit(event -> {
            Order order = event.getRowValue();
            order.setOrderID(event.getNewValue());
            try {
                updateData("EDITEDBY", loginUsername, order.getOrderID());
            } catch (IOException ex) {
            }
        });
    }

    // Update the Order Database when there is an change to cellValue in TableView
    @FXML
    public void updateData(String column, String newValue, String orderID) throws IOException {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Orders.db")) {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Orders SET " + column + " = ?, EDITEDBY = ?, ORDERTIMESTAMP = ? WHERE ORDERID = ? ");
            stmt.setString(1, newValue);
            stmt.setString(2, loginUsername);
            stmt.setString(3, getTimeStamp());
            stmt.setString(4, orderID);
            stmt.execute();
            initialize();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    // Creates a timestamp & converts it into a string when an order is created
    
    public String getTimeStamp() {
        
        Date date = new Date();
        Timestamp ts = new Timestamp(date.getTime());
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");  
        String finalString = formatter.format(ts);
        return finalString;
    }
    
    //Fully working supplierlist comboBox
    public void getSupplierList() {
        try(Connection conn = DriverManager.getConnection("jdbc:sqlite:Suppliers.db")) {
            ObservableList<String> supplierList = FXCollections.observableArrayList();
            String selectQuery = "SELECT SUPPLIERID, SUPPLIERNAME FROM Supplier";
            PreparedStatement pstmt = conn.prepareStatement(selectQuery);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                supplierList.add(rs.getString(1)+ ". " +rs.getString(2));
            }
            supplierListCombBox.setValue("Select Supplier");
            supplierListCombBox.setItems(supplierList);
            conn.close();
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    //Fully working productlist comboBox
    public void getProductList() {
        try(Connection conn = DriverManager.getConnection("jdbc:sqlite:Products.db")) {
            ObservableList<String> productList = FXCollections.observableArrayList();
            String selectQuery = "SELECT PRODUCTNAME FROM Product";
            PreparedStatement pstmt = conn.prepareStatement(selectQuery);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                productList.add(rs.getString(1));
            }
            productListComboBox.setValue("Select Product");
            productListComboBox.setItems(productList);
            conn.close();
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    // Create a combox box for Order Status
    public void getComboBox() {
        ObservableList<String> orderStatusList = FXCollections.observableArrayList("Order Placed", "Order Processing", "Order Cancelled", "Order Failed", "Order Packed", "Order Picked", "Order Dispatched", "Order Refunded");
        orderStatusComboBox.setValue("Select");
        orderStatusComboBox.setItems(orderStatusList);
    }
    
    //Creating a searchbar/filteredlist with comboBox & textbox 
    public void getFilteredList() throws SQLException {
        ObservableList<Order> orderlist = FXCollections.observableArrayList();
        orderlist = database.getOrder();
        orders.setItems(orderlist);
        FilteredList<Order> ordersFiltered = new FilteredList(orderlist, p -> true);
        ObservableList<String> searchOrderList = FXCollections.observableArrayList("Order ID","Product Name","Supplier ID","Order Status","Order Timestamp");

        searchComboBox.setValue("Order ID");
        searchComboBox.setItems(searchOrderList);
        
        searchTextField.setOnKeyReleased(keyEvent -> {
                switch (searchComboBox.getValue().toString()) {
                    case "Order ID":
                        ordersFiltered.setPredicate(p -> p.getOrderID().contains(searchTextField.getText().trim()));
                        orders.setItems(ordersFiltered);
                        break;
                    case "Product Name":
                        ordersFiltered.setPredicate(p -> p.getProductName().contains(searchTextField.getText().trim()));
                        orders.setItems(ordersFiltered);
                        break;
                    case "Supplier ID":
                        ordersFiltered.setPredicate(p -> p.getSupplierID().contains(searchTextField.getText().trim()));
                        orders.setItems(ordersFiltered);
                        break;
                    case "Order Status":
                        ordersFiltered.setPredicate(p -> p.getOrderStatus().contains(searchTextField.getText().trim()));
                        orders.setItems(ordersFiltered);
                        break;
                    case "Order Timestamp":
                        ordersFiltered.setPredicate(p -> p.getOrderTimeStamp().contains(searchTextField.getText().trim()));
                        orders.setItems(ordersFiltered);
                        break;        
            }

        });
    }
}
