package smokegm.infs2605;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.chart.PieChart;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class HomeController {
    
    @FXML
    TableView<Order> orders;
    @FXML
    TableColumn<Order, String> orderID;
    @FXML
    TableColumn<Order, String> productName;
    @FXML
    TableColumn<Order, String> supplierID;
    @FXML
    TableColumn<Order, Integer> quantity;
    @FXML
    TableColumn<Order, String> orderStatus;
    @FXML
    TableColumn<Order, Long> orderTimeStamp;
    @FXML
    TableColumn<Order, String> editedBy;
    
    @FXML
    ComboBox searchComboBox;

    @FXML
    TextField searchTextField;
    
    OrderDatabase database = new OrderDatabase();

    @FXML private Label userGreeting;
    @FXML private PieChart piechart;
    
    public void initialize() throws IOException, SQLException
    {
        //This chunk of code reads the name and company of the current user.
        File exists = new File("details.txt");
        if (exists.exists())
        {
            FileReader userfr = new FileReader("details.txt");
            BufferedReader userbr = new BufferedReader(userfr);
            String loginUsername = userbr.readLine();
            int userID = Integer.parseInt(userbr.readLine());
            if (loginUsername != null)
            {
                userGreeting.setText("Logged in as " + loginUsername + ".");
            }
            userbr.close();
            getFilteredList();
        }
        // Init TableView
        
        ObservableList<Order> orderlist = FXCollections.observableArrayList();
        orderlist = database.getOrder();
        orders.setItems(orderlist);
        orderID.setCellValueFactory(new PropertyValueFactory<>("orderID"));
        productName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        supplierID.setCellValueFactory(new PropertyValueFactory<>("supplierID"));
        quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        orderStatus.setCellValueFactory(new PropertyValueFactory<>("orderStatus"));
        orderTimeStamp.setCellValueFactory(new PropertyValueFactory<>("orderTimeStamp"));
        editedBy.setCellValueFactory(new PropertyValueFactory<>("editedBy"));
        //Initilises pie chart
        
        Statement st;
        ResultSet rs;
        try 
        {
            Connection conn = DriverManager.getConnection("jdbc:sqlite:Orders.db");
            st = conn.createStatement();
            String query = "SELECT ORDERSTATUS, COUNT(*) FROM Orders GROUP BY ORDERSTATUS";
            rs = st.executeQuery(query);
            ObservableList<PieChart.Data> piedata = FXCollections.observableArrayList();
            while (rs.next()) {
                piedata.add(new PieChart.Data(rs.getString(1), rs.getInt(2)));
            }
            //Shows value of each pie slice
            piedata.forEach(data
                    -> data.nameProperty().bind(
                            Bindings.concat(data.getName(), " (", data.pieValueProperty(), " )")));
            piechart.setData(piedata);
            st.close();
        }
        catch (SQLException e)
            {
            }
    }
    
    @FXML
    private void switchToLogin() throws IOException {
        App.setRoot("login");
    }
    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("home");
    }
    @FXML
    private void switchToSuppliers() throws IOException {
        App.setRoot("suppliers");
    }
    @FXML
    private void switchToOrders() throws IOException {
        App.setRoot("orders");
    }
    @FXML
    private void switchToAbout() throws IOException {
        App.setRoot("about");
    }
    @FXML
    private void switchToProducts() throws IOException {
        App.setRoot("products");
    }
    @FXML
    private void switchToHelp() throws IOException {
        App.setRoot("help");
    }
    
    
    public void getFilteredList() throws SQLException {
        ObservableList<Order> orderlist = FXCollections.observableArrayList();
        orderlist = database.getOrder();
        orders.setItems(orderlist);
        FilteredList<Order> ordersFiltered = new FilteredList(orderlist, p -> true);
        ObservableList<String> searchOrderList = FXCollections.observableArrayList("Order ID", "Product Name", "Supplier ID", "Order Status", "Order Timestamp");

        searchComboBox.setValue("Order ID");
        searchComboBox.setItems(searchOrderList);

        searchTextField.setOnKeyReleased(keyEvent -> {
            switch (searchComboBox.getValue().toString()) {
                case "Order ID":
                    ordersFiltered.setPredicate(p -> p.getOrderID().contains(searchTextField.getText().trim()));
                    orders.setItems(ordersFiltered);
                    break;
                case "Product Name":
                    ordersFiltered.setPredicate(p -> p.getProductName().contains(searchTextField.getText().trim()));
                    orders.setItems(ordersFiltered);
                    break;
                case "Supplier ID":
                    ordersFiltered.setPredicate(p -> p.getSupplierID().contains(searchTextField.getText().trim()));
                    orders.setItems(ordersFiltered);
                    break;
                case "Order Status":
                    ordersFiltered.setPredicate(p -> p.getOrderStatus().contains(searchTextField.getText().trim()));
                    orders.setItems(ordersFiltered);
                    break;
                case "Order Timestamp":
                    ordersFiltered.setPredicate(p -> p.getOrderTimeStamp().contains(searchTextField.getText().trim()));
                    orders.setItems(ordersFiltered);
                    break;
            }

        });
    }
}
