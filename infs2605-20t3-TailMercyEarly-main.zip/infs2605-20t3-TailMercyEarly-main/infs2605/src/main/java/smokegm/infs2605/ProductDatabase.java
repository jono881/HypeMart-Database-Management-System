package smokegm.infs2605;
import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ProductDatabase 
{
    public ObservableList<Product> getProduct() throws SQLException 
    {
        ObservableList<Product> productList;
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Products.db")) {
            Statement st = conn.createStatement();
            String query = "SELECT * FROM Product";
            ResultSet rs = st.executeQuery(query);
            productList = FXCollections.observableArrayList();
            while (rs.next())
            {
                productList.add(new Product(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5), rs.getFloat(6)));
            }
            st.close();
            conn.close();
        }
        return productList;
    }
}
