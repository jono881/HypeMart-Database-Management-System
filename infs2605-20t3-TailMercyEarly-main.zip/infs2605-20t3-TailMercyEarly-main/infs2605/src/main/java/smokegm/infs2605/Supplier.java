//the id variable in this database is the FK to isSupplier in the user database


package smokegm.infs2605;

public class Supplier {
    private String supplierID;
    private String supplierName;
    private String email;
    private String phoneNumber;
    private String locations;
    private String category;
    
    public Supplier()
    {
    }

    public Supplier(String supplierID, String supplierName, String email, String phoneNumber, String locations, String category) {
        this.supplierID = supplierID;
        this.supplierName = supplierName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.locations = locations;
        this.category = category;
    }

    public String getSupplierID() {
        return supplierID;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getLocations() {
        return locations;
    }

    public String getCategory() {
        return category;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setLocations(String locations) {
        this.locations = locations;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    
}
