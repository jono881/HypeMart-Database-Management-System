package smokegm.infs2605;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import org.apache.commons.io.FileUtils;

public class App extends Application {

    private static Scene scene;

    @Override
    public void start(Stage stage) throws IOException, SQLException 
    {
        
        //If databases do not yet exist for this device, attempts to create databases with sample data
        
        
        File file = new File("initdb.txt"); //uses an empty text file as flag to check if databases have been created because I'm a lazy ass.
        if (file.createNewFile())
        {
        File users = new File("Users.db");
        File defusers = new File("UsersDefaults.db");
        FileUtils.copyFile(defusers,users);
        
        File suppliers = new File("Suppliers.db");
        File defsuppliers = new File("SuppliersDefaults.db");
        FileUtils.copyFile(defsuppliers,suppliers);
        
        File orders = new File("Orders.db");
        File deforders = new File("OrdersDefaults.db");
        FileUtils.copyFile(deforders, orders);
        
        File products = new File("Products.db");
        File defproducts = new File("ProductsDefaults.db");
        FileUtils.copyFile(defproducts, products);
        }
        
        
        
        scene = new Scene(loadFXML("login"), 1000, 700);
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false); //Prevents resizing problems because I can't be bothered with dynamically sized menubars
        stage.setTitle("Invent Story IMS"); //generic name, remember to change this later
        stage.getIcons().add(new Image("file:src/main/java/smokegm/infs2605/icon.png")); //app icon
    }

    
    
    //loaders, don't need to change or this all breaks
    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }

}