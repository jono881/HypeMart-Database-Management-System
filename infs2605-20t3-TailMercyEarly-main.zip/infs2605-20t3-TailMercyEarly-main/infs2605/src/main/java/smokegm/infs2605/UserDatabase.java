package smokegm.infs2605;
import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class UserDatabase 
{
    
    
    //This class is currently empty, might be deleted later
    //mainly just artifacts left from an earlier test
    
    
    public void initialize() throws SQLException
    {
    }
    //Unused function which allows for user data to be pushed to TableView
/*    public ObservableList<User> getUser() throws SQLException 
    {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:Users.db");
        Statement st = conn.createStatement();
        String query = "SELECT * FROM User";
        ResultSet rs = st.executeQuery(query);
        ObservableList<User> userList = FXCollections.observableArrayList();
        while (rs.next())
        {
            userList.add(new User(rs.getString(1),rs.getString(2),rs.getInt(3)));
        }
        st.close();
        conn.close();
        return userList;
    }   */
}
