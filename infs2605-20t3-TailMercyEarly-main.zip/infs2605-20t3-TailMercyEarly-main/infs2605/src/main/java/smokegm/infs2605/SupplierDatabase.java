package smokegm.infs2605;
import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class SupplierDatabase 
{
    public ObservableList<Supplier> getSupplier() throws SQLException 
    {
        ObservableList<Supplier> supplierList;
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Suppliers.db")) {
            Statement st = conn.createStatement();
            String query = "SELECT * FROM Supplier";
            ResultSet rs = st.executeQuery(query);
            supplierList = FXCollections.observableArrayList();
            while (rs.next())
            {
                supplierList.add(new Supplier(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5), rs.getString(6)));
            }
            st.close();
            conn.close();
        }
        return supplierList;
    }
}
