package smokegm.infs2605;

import java.io.IOException;
import javafx.fxml.FXML;
import java.sql.*;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.collections.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.ComboBox;

public class MultiOrdersController {
    @FXML
    TableView<MultiOrders> multiOrders;
    
    @FXML
    TableColumn<MultiOrders, String> supplierName;
    
    @FXML
    TableColumn<MultiOrders, String> productName;
    
    @FXML
    TableColumn<MultiOrders, Integer> productQuantity;

    @FXML
    Button addButton;
    
    @FXML
    ComboBox supplierListCombBox;
    
    @FXML
    ComboBox productListComboBox;
    
    @FXML
    TextField productQuantityText;

    OrderDatabase orderDatabase = new OrderDatabase();
    //Initializes the Order Screen with default properties
    @FXML
    public void initialize() throws SQLException {
        supplierName.setCellValueFactory(new PropertyValueFactory<>("supplierName"));
        productName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        productQuantity.setCellValueFactory(new PropertyValueFactory<>("productQuantity"));
        getSupplierList();
        getProductList();
        populateTable();
    }


    @FXML
    private void switchToLogin() throws IOException {
        App.setRoot("login");
    }

    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("home");
    }

    @FXML
    private void switchToSuppliers() throws IOException {
        App.setRoot("suppliers");
    }

    @FXML
    private void switchToOrders() throws IOException {
        App.setRoot("orders");
    }

    @FXML
    private void switchToAbout() throws IOException {
        App.setRoot("about");
    }

    @FXML
    private void switchToProducts() throws IOException {
        App.setRoot("products");
    }

    @FXML
    private void switchToHelp() throws IOException {
        App.setRoot("help");
    }
    
    // Fully Functional
    
    //Fully working supplierlist comboBox
    public void getSupplierList() {
        try(Connection conn = DriverManager.getConnection("jdbc:sqlite:Suppliers.db")) {
            ObservableList<String> supplierList = FXCollections.observableArrayList();
            String selectQuery = "SELECT SUPPLIERID, SUPPLIERNAME FROM Supplier";
            PreparedStatement pstmt = conn.prepareStatement(selectQuery);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                supplierList.add(rs.getString(1)+ ". " +rs.getString(2));
            }
            supplierListCombBox.setValue("Select");
            supplierListCombBox.setItems(supplierList);
            conn.close();
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    //Fully working productlist comboBox
    public void getProductList() {
        try(Connection conn = DriverManager.getConnection("jdbc:sqlite:Products.db")) {
            ObservableList<String> productList = FXCollections.observableArrayList();
            String selectQuery = "SELECT PRODUCTID, PRODUCTNAME FROM Product";
            PreparedStatement pstmt = conn.prepareStatement(selectQuery);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                productList.add(rs.getString(1)+ ". " +rs.getString(2));
            }
            productListComboBox.setValue("Select");
            productListComboBox.setItems(productList);
            conn.close();
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    //Partially Functional Methods
    
    //This method was able to update the tableview dynamically and DOES NOT update database at the moment. 
    //Currently this method does not work in conjunction with populateTable() method.
    //Pretty much when program is run, first populateTable() will appear but if you click add button then those values disappear and replace with combobox box values.
    @FXML
    public void switchToAdd() throws IOException, SQLException {
        
        ObservableList<MultiOrders> multiOrdersList = FXCollections.observableArrayList();
        int quantityEntered = Integer.parseInt(productQuantityText.getText());
        multiOrdersList.add(new MultiOrders(supplierListCombBox.getValue().toString(), productListComboBox.getValue().toString(), quantityEntered));
        multiOrders.setItems(multiOrdersList);
        
        //Also cannot add multiple products yet. Only single products here as well.
        //If you add another product it will overwrite the first row instead of inserting into second row.
    }
    
    //This method will work once it has been initialised using populateTable(); under initialize(). Does not work when addButton is clicked.
    public void populateTable() {
        ObservableList<MultiOrders> multiOrdersList = FXCollections.observableArrayList();
        multiOrdersList = orderDatabase.getMultiOrders();
        multiOrders.setItems(multiOrdersList);
    }
        
    
    
}
