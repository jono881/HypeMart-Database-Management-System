package smokegm.infs2605;

import java.io.IOException;
import javafx.fxml.FXML;

public class AboutController {     
    @FXML
    private void switchToLogin() throws IOException {
        App.setRoot("login");
    }
    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("home");
    }
    @FXML
    private void switchToSuppliers() throws IOException {
        App.setRoot("suppliers");
    }
    @FXML
    private void switchToOrders() throws IOException {
        App.setRoot("orders");
    }
    @FXML
    private void switchToAbout() throws IOException {
        App.setRoot("about");
    }
    @FXML
    private void switchToProducts() throws IOException {
        App.setRoot("products");
    }
    @FXML
    private void switchToHelp() throws IOException {
        App.setRoot("help");
    }
}
