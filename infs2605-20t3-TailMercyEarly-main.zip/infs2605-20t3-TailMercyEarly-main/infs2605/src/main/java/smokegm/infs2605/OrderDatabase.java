package smokegm.infs2605;

import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class OrderDatabase {

    public ObservableList<Order> getOrder() throws SQLException {
        ObservableList<Order> orderList;
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Orders.db")) {
            Statement st = conn.createStatement();
            String query = "SELECT * FROM Orders ";
            ResultSet rs = st.executeQuery(query);
            orderList = FXCollections.observableArrayList();
            while (rs.next()) {
                orderList.add(new Order(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7)));
            }
            st.close();
            conn.close();
        }
        return orderList;
    }
    public ObservableList<Order> getSupplierOrder(int userID) throws SQLException {
        ObservableList<Order> orderList;
        try ( Connection conn = DriverManager.getConnection("jdbc:sqlite:Orders.db")) {
            Statement st = conn.createStatement();
            String query = "SELECT * FROM Orders WHERE SUPPLIERID = '" + Integer.toString(userID) + "'";
            ResultSet rs = st.executeQuery(query);
            orderList = FXCollections.observableArrayList();
            while (rs.next()) {
                orderList.add(new Order(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7)));
            }
            st.close();
            conn.close();
        }
        return orderList;
    }
    //Added to allow the populateTable function under MultiOrdersController to work.
    public ObservableList<MultiOrders> getMultiOrders() {
        ObservableList<MultiOrders> multiOrdersList = null;
        try{
            Connection connOrders = DriverManager.getConnection("jdbc:sqlite:Orders.db");
            Statement orderStatement = connOrders.createStatement();
            String orderQuery = "SELECT SUPPLIERID, PRODUCTID, QUANTITY FROM Orders ";
            ResultSet rs = orderStatement.executeQuery(orderQuery);
            multiOrdersList = FXCollections.observableArrayList();
            while (rs.next()) {
                multiOrdersList.add(new MultiOrders(rs.getString(1), rs.getString(2), rs.getInt(3)));
            }
            orderStatement.close();
            connOrders.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return multiOrdersList;
    }
}
