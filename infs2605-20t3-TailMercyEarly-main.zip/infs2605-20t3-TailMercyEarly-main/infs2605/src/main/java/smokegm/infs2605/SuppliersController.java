package smokegm.infs2605;

import java.io.IOException;
import javafx.fxml.FXML;
import java.sql.*;
import javafx.beans.binding.Bindings;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.collections.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableRow;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseButton;

public class SuppliersController {
    
    @FXML
    TableView<Supplier> suppliers;
    @FXML
    TableColumn<Supplier, String> supplierID;
    @FXML
    TableColumn<Supplier, String> supplierName;
    @FXML
    TableColumn<Supplier, String> email;
    @FXML
    TableColumn<Supplier, String> phoneNumber;
    @FXML
    TableColumn<Supplier, String> locations;
    @FXML
    TableColumn<Supplier, String> category;
    
    @FXML
    TextField supplierIdText;
    
    @FXML
    TextField supplierNameText;
    
    @FXML
    TextField emailText;
    
    @FXML
    TextField phoneNumberText;
    
    @FXML
    TextField locationsText;
    
    @FXML
    TextField categoryText;
    
    @FXML
    Button addButton;
    
    @FXML
    Button modifyButton;
    
    @FXML
    Button deleteButton;
    
    @FXML
    Label errornumber;
    
    SupplierDatabase database = new SupplierDatabase();
    
    //Initializes the Supplier Screen with default properties
    @FXML
    public void initialize() throws SQLException 
    {
        errornumber.setVisible(false);
        suppliers.setEditable(true);
        editChanged();
        
        ObservableList<Supplier> supplierlist = FXCollections.observableArrayList();
        supplierlist = database.getSupplier();        
        suppliers.setItems(supplierlist);
        
        supplierID.setCellValueFactory(new PropertyValueFactory<>("supplierID"));
        supplierName.setCellValueFactory(new PropertyValueFactory<>("supplierName"));
        email.setCellValueFactory(new PropertyValueFactory<>("email"));
        phoneNumber.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        locations.setCellValueFactory(new PropertyValueFactory<>("locations"));
        category.setCellValueFactory(new PropertyValueFactory<>("category"));
        
        deleteButton.disableProperty().bind(Bindings.isEmpty(suppliers.getSelectionModel().getSelectedItems()));
        mousePressed();
    }   
    
    @FXML
    private void switchToLogin() throws IOException {
        App.setRoot("login");
    }
    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("home");
    }
    @FXML
    private void switchToSuppliers() throws IOException {
        App.setRoot("suppliers");
    }
    @FXML
    private void switchToOrders() throws IOException {
        App.setRoot("orders");
    }
    @FXML
    private void switchToAbout() throws IOException {
        App.setRoot("about");
    }
    @FXML
    private void switchToProducts() throws IOException {
        App.setRoot("products");
    }
    @FXML
    private void switchToHelp() throws IOException {
        App.setRoot("help");
    }
    
    //Add Supplier Record to Supplier Database & TableView when addButton is clicked
    @FXML
    public void switchToAdd() throws IOException {
        try(Connection conn = DriverManager.getConnection("jdbc:sqlite:Suppliers.db")) 
        {
            int maxlength = 10;
        
            if (phoneNumberText.getLength() > maxlength) {
                errornumber.setVisible(true);
                return;
            } else {          
            String databaseUpdate = "INSERT INTO Supplier (SUPPLIERID,SUPPLIERNAME,EMAIL,PHONENUMBER,LOCATIONS,CATEGORY) VALUES(?,?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(databaseUpdate);
            pstmt.setString(1,supplierIdText.getText());
            pstmt.setString(2,supplierNameText.getText());
            pstmt.setString(3,emailText.getText());
            pstmt.setString(4,phoneNumberText.getText());
            pstmt.setString(5,locationsText.getText());
            pstmt.setString(6,categoryText.getText());
            pstmt.execute();
            initialize();
            conn.close();
            supplierIdText.clear();
            supplierNameText.clear();
            emailText.clear();
            phoneNumberText.clear();
            locationsText.clear();
            categoryText.clear();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }
    //Retrieves details of the selected Row once left click is pressed on mouse
    @FXML
    public void mousePressed() {
        suppliers.setRowFactory(mousePress -> {
            TableRow<Supplier> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if(! row.isEmpty() && event.getButton()==MouseButton.PRIMARY && event.getClickCount() == 1) {
                    Supplier selectedSupplier = suppliers.getSelectionModel().getSelectedItem();
                    supplierIdText.setText(selectedSupplier.getSupplierID());
                    supplierNameText.setText(selectedSupplier.getSupplierName());
                    emailText.setText(selectedSupplier.getEmail());
                    phoneNumberText.setText(selectedSupplier.getPhoneNumber());
                    locationsText.setText(selectedSupplier.getLocations());
                    categoryText.setText(selectedSupplier.getCategory()); 
                } else{
                    supplierIdText.clear();
                    supplierNameText.clear();
                    emailText.clear();
                    phoneNumberText.clear();
                    locationsText.clear();
                    categoryText.clear();
                }
            });
            return row;
        });
    }
    
    //Updates the Supplier Database with the new Supplier Record as per the user needs using the modifyButton
    @FXML
    public void switchToModify() throws IOException {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Suppliers.db")) {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Supplier SET SUPPLIERID = ?, SUPPLIERNAME = ?, EMAIL = ?, PHONENUMBER = ?, LOCATIONS = ?, CATEGORY = ? WHERE SUPPLIERID = ? ");
            stmt.setString(1, supplierIdText.getText());
            stmt.setString(2, supplierNameText.getText());
            stmt.setString(3, emailText.getText());
            stmt.setString(4, phoneNumberText.getText());
            stmt.setString(5, locationsText.getText());
            stmt.setString(6, categoryText.getText());
            stmt.setString(7, supplierIdText.getText());
            stmt.execute();
            initialize();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    // Remove Supplier Record FROM Supplier Database & TableView when deleteButton is clicked
    @FXML
    public void switchToDelete() throws IOException {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Suppliers.db")) 
        {
            Supplier selectedSupplier = suppliers.getSelectionModel().getSelectedItem();
            String supplierID = selectedSupplier.getSupplierID();
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM Supplier WHERE SUPPLIERID = ? ");
            stmt.setString(1, supplierID);
            stmt.execute();
            initialize();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Functionality to Edit Cell Values in TableView
    @FXML
    public void editChanged() {
        supplierID.setCellFactory(TextFieldTableCell.forTableColumn());
        
        supplierID.setOnEditCommit (event -> {
        Supplier supplier = event.getRowValue();
        supplier.setSupplierID(event.getNewValue());
        updateData("supplierID", event.getNewValue(), supplier.getSupplierID());
    });
        supplierName.setCellFactory(TextFieldTableCell.forTableColumn());
        
        supplierName.setOnEditCommit (event -> {
        Supplier supplier = event.getRowValue();
        supplier.setSupplierName(event.getNewValue());
        updateData("supplierName", event.getNewValue(), supplier.getSupplierID());
    });
        email.setCellFactory(TextFieldTableCell.forTableColumn());
        
        email.setOnEditCommit (event -> {
        Supplier supplier = event.getRowValue();
        supplier.setEmail(event.getNewValue());
        updateData("email", event.getNewValue(), supplier.getSupplierID());
    });
        phoneNumber.setCellFactory(TextFieldTableCell.forTableColumn());
        
        phoneNumber.setOnEditCommit (event -> {
        Supplier supplier = event.getRowValue();
        supplier.setPhoneNumber(event.getNewValue());
        updateData("phoneNumber", event.getNewValue(), supplier.getSupplierID());
    });
        locations.setCellFactory(TextFieldTableCell.forTableColumn());
        
        locations.setOnEditCommit (event -> {
        Supplier supplier = event.getRowValue();
        supplier.setLocations(event.getNewValue());
        updateData("locations", event.getNewValue(), supplier.getSupplierID());
    });
        category.setCellFactory(TextFieldTableCell.forTableColumn());
        
        category.setOnEditCommit (event -> {
        Supplier supplier = event.getRowValue();
        supplier.setCategory(event.getNewValue());
        updateData("category", event.getNewValue(), supplier.getSupplierID());
    });        
    }
    
    // Update the Supplier Database when there is an change to cellValue in TableView
    @FXML
    public void updateData(String column, String newValue, String supplierID) {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Suppliers.db")) 
        {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Supplier SET "+column+" = ? WHERE SUPPLIERID = ? ");
            stmt.setString(1, newValue);
            stmt.setString(2, supplierID);
            stmt.execute();
            initialize();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    //Clears all textfields
    public void clearTextFields() {
        supplierIdText.clear();
        supplierNameText.clear();
        emailText.clear();
        phoneNumberText.clear();
        locationsText.clear();
        categoryText.clear();
    }
    
}
