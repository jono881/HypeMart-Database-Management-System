//the id variable in this database is the FK to isProduct in the user database


package smokegm.infs2605;

public class Product {
private String productID;
private String productName;
private String productDescription;
private String category;
private int stockLevel;
private float price;
    
    public Product() {
    }

    public Product(String productID, String productName, String productDescription, String category, int stockLevel, float price) {
        this.productID = productID;
        this.productName = productName;
        this.productDescription = productDescription;
        this.category = category;
        this.stockLevel = stockLevel;
        this.price = price;
    }

    public String getProductID() {
        return productID;
    }

    public String getProductName() {
        return productName;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public String getCategory() {
        return category;
    }

    public int getStockLevel() {
        return stockLevel;
    }

    public float getPrice() {
        return price;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setStockLevel(int stockLevel) {
        this.stockLevel = stockLevel;
    }

    public void setPrice(float price) {
        this.price = price;
    }
    
    
}
