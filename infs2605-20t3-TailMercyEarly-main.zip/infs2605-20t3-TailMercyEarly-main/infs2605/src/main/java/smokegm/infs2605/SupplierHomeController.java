package smokegm.infs2605;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javafx.fxml.FXML;
import java.sql.*;
import java.text.SimpleDateFormat;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.collections.*;
import javafx.scene.control.Label;
import javafx.scene.control.TableRow;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseButton;

public class SupplierHomeController {

    @FXML
    TableView<Order> orders;
    @FXML
    TableColumn<Order, String> orderID;
    @FXML
    TableColumn<Order, String> productName;
    @FXML
    TableColumn<Order, String> supplierID;
    @FXML
    TableColumn<Order, Integer> quantity;
    @FXML
    TableColumn<Order, String> orderStatus;
    @FXML
    TableColumn<Order, String> orderTimeStamp;
    @FXML
    TableColumn<Order, String> editedBy;
    
    @FXML
    Label userGreeting;

    OrderDatabase database = new OrderDatabase();
    
    private String loginUsername;

    //Initializes the Order Screen with default properties
    @FXML
    public void initialize() throws SQLException, IOException {
        File exists = new File("details.txt");
        int userID;

        FileReader userfr = new FileReader("details.txt");
        BufferedReader userbr = new BufferedReader(userfr);
        loginUsername = userbr.readLine();
        userGreeting.setText("Logged in as " + loginUsername + " (Supplier Access).");
        userID = Integer.parseInt(userbr.readLine());
        userbr.close();
        orders.setEditable(true);
        editChanged();

        ObservableList<Order> orderlist = FXCollections.observableArrayList();
        orderlist = database.getSupplierOrder(userID);
        orders.setItems(orderlist);

        orderID.setCellValueFactory(new PropertyValueFactory<>("orderID"));
        productName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        supplierID.setCellValueFactory(new PropertyValueFactory<>("supplierID"));
        quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        orderStatus.setCellValueFactory(new PropertyValueFactory<>("orderStatus"));
        orderTimeStamp.setCellValueFactory(new PropertyValueFactory<>("orderTimeStamp"));
        editedBy.setCellValueFactory(new PropertyValueFactory<>("editedBy"));
        mousePressed();
       
    }


    @FXML
    private void switchToLogin() throws IOException {
        App.setRoot("login");
    }
    
    //Retrieves details of the selected Row once left click is pressed on mouse
    @FXML
    public void mousePressed() {
        orders.setRowFactory(mousePress -> 
        {
            TableRow<Order> row = new TableRow<>();
            row.setOnMouseClicked(event -> 
            {
                if(! row.isEmpty() && event.getButton()==MouseButton.PRIMARY && event.getClickCount() == 1) {
                    Order selectedOrder = orders.getSelectionModel().getSelectedItem();
                    ObservableList<String> orderStatusList = FXCollections.observableArrayList("Order Placed", "Order Processing", "Order Cancelled", "Order Failed", "Order Packed", "Order Picked", "Order Dispatched", "Order Refunded");
                    orderStatus.setCellFactory(ComboBoxTableCell.forTableColumn(orderStatusList));
                }
            });
            return row;
        });
    }
    

    // Functionality to Edit Cell Values in TableView
    @FXML
    public void editChanged() {
        orderStatus.setCellFactory(TextFieldTableCell.forTableColumn());

        orderStatus.setOnEditCommit(event -> {
            Order order = event.getRowValue();
            order.setOrderStatus(event.getNewValue());
            try 
            {
                updateData("ORDERSTATUS", event.getNewValue(), order.getOrderID());
            } 
            catch (IOException ex) 
            {
                System.out.println(ex.getMessage());
            }
        });

    }

    // Update the Order Database when there is an change to cellValue in TableView
    @FXML
    public void updateData(String column, String newValue, String orderID) throws IOException{
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Orders.db")) {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Orders SET " + column + " = ?, EDITEDBY = ?, ORDERTIMESTAMP = ? WHERE ORDERID = ? ");
            stmt.setString(1, newValue);
            stmt.setString(2, loginUsername);
            stmt.setString(3, getTimeStamp());
            stmt.setString(4, orderID);
            stmt.execute();
            initialize();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    public String getTimeStamp() {

        java.util.Date date = new java.util.Date();
        Timestamp ts = new Timestamp(date.getTime());
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        String finalString = formatter.format(ts);
        return finalString;
    }
}
