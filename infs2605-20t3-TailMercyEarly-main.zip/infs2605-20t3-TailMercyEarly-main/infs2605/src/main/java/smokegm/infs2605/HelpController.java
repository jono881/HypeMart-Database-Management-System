package smokegm.infs2605;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import org.apache.commons.io.FileUtils;

public class HelpController { 
    
    @FXML private Label restoreText;
    
    @FXML
    private void switchToLogin() throws IOException {
        App.setRoot("login");
    }
    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("home");
    }
    @FXML
    private void switchToSuppliers() throws IOException {
        App.setRoot("suppliers");
    }
    @FXML
    private void switchToOrders() throws IOException {
        App.setRoot("orders");
    }
    @FXML
    private void switchToAbout() throws IOException {
        App.setRoot("about");
    }
    @FXML
    private void switchToProducts() throws IOException {
        App.setRoot("products");
    }
    @FXML
    private void switchToHelp() throws IOException {
        App.setRoot("help");
    }
    @FXML
    private void restoreDefault() throws IOException,SQLException {
        restoreText.setVisible(true);
        File users = new File("Users.db");
        File defusers = new File("UsersDefaults.db");
        FileUtils.copyFile(defusers,users);
        
        File suppliers = new File("Suppliers.db");
        File defsuppliers = new File("SuppliersDefaults.db");
        FileUtils.copyFile(defsuppliers,suppliers);
        
        File orders = new File("Orders.db");
        File deforders = new File("OrdersDefaults.db");
        FileUtils.copyFile(deforders, orders);
        
        File products = new File("Products.db");
        File defproducts = new File("ProductsDefaults.db");
        FileUtils.copyFile(defproducts, products);
    }
}
