package smokegm.infs2605;

import java.io.IOException;
import javafx.fxml.FXML;
import java.sql.*;
import javafx.beans.binding.Bindings;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.collections.*;
import javafx.scene.control.Button;
import javafx.scene.control.TableRow;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseButton;
import javafx.util.converter.FloatStringConverter;
import javafx.util.converter.IntegerStringConverter;

public class ProductsController {
    
    @FXML
    TableView<Product> products;
    @FXML
    TableColumn<Product, String> productID;
    @FXML
    TableColumn<Product, String> productName;
    @FXML
    TableColumn<Product, String> productDescription;
    @FXML
    TableColumn<Product, String> category;
    @FXML
    TableColumn<Product, Integer> stockLevel;
    @FXML
    TableColumn<Product, Float> price;
    
    @FXML
    TextField productIdText;
    
    @FXML
    TextField productNameText;
    
    @FXML
    TextField productDescriptionText;
    
    @FXML
    TextField categoryText;
    
    @FXML
    TextField stockLevelText;
    
    @FXML
    TextField priceText;
    
    @FXML
    Button addButton;
    
    @FXML
    Button deleteButton;
    
    ProductDatabase database = new ProductDatabase();
    
    //Initializes the Product Screen with default properties
    @FXML
    public void initialize() throws SQLException 
    {
        products.setEditable(true);
        editChanged();
        
        ObservableList<Product> productlist = FXCollections.observableArrayList();
        productlist = database.getProduct();        
        products.setItems(productlist);
        
        productID.setCellValueFactory(new PropertyValueFactory<>("productID"));
        productName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        productDescription.setCellValueFactory(new PropertyValueFactory<>("productDescription"));
        category.setCellValueFactory(new PropertyValueFactory<>("category"));
        stockLevel.setCellValueFactory(new PropertyValueFactory<>("stockLevel"));
        price.setCellValueFactory(new PropertyValueFactory<>("price"));
        
        deleteButton.disableProperty().bind(Bindings.isEmpty(products.getSelectionModel().getSelectedItems()));
        mousePressed();
    }   
    
    @FXML
    private void switchToLogin() throws IOException {
        App.setRoot("login");
    }
    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("home");
    }
    @FXML
    private void switchToSuppliers() throws IOException {
        App.setRoot("suppliers");
    }
    @FXML
    private void switchToOrders() throws IOException {
        App.setRoot("orders");
    }
    @FXML
    private void switchToAbout() throws IOException {
        App.setRoot("about");
    }
    @FXML
    private void switchToProducts() throws IOException {
        App.setRoot("products");
    }
    @FXML
    private void switchToHelp() throws IOException {
        App.setRoot("help");
    }
    
    //Add Product Record to Product Database & TableView when addButton is clicked
    @FXML
    public void switchToAdd() throws IOException {
        try(Connection conn = DriverManager.getConnection("jdbc:sqlite:Products.db")) 
        {
            String databaseUpdate = "INSERT INTO Product (PRODUCTID,PRODUCTNAME,PRODUCTDESCRIPTION,CATEGORY,STOCKLEVEL,PRICE) VALUES(?,?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(databaseUpdate);
            pstmt.setString(1,productIdText.getText());
            pstmt.setString(2,productNameText.getText());
            pstmt.setString(3,productDescriptionText.getText());
            pstmt.setString(4,categoryText.getText());
            pstmt.setInt(5,Integer.parseInt(stockLevelText.getText()));
            pstmt.setFloat(6,Float.parseFloat(priceText.getText()));
            pstmt.execute();
            initialize();
            conn.close();
            productIdText.clear();
            productNameText.clear();
            productDescriptionText.clear();
            categoryText.clear();
            stockLevelText.clear();
            priceText.clear();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
     //Retrieves details of the selected Row once left click is pressed on mouse
    @FXML
    public void mousePressed() {
        products.setRowFactory(mousePress -> {
            TableRow<Product> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if(! row.isEmpty() && event.getButton()==MouseButton.PRIMARY && event.getClickCount() == 1) {
                    Product selectedProduct = products.getSelectionModel().getSelectedItem();
                    productIdText.setText(selectedProduct.getProductID());
                    productNameText.setText(selectedProduct.getProductName());
                    productDescriptionText.setText(selectedProduct.getProductDescription());
                    categoryText.setText(selectedProduct.getCategory());
                    stockLevelText.setText(String.valueOf(selectedProduct.getStockLevel()));
                    priceText.setText(String.valueOf(selectedProduct.getPrice())); 
                } else{
                    productIdText.clear();
                    productNameText.clear();
                    productDescriptionText.clear();
                    categoryText.clear();
                    stockLevelText.clear();
                    priceText.clear();
                }
            });
            return row;
        });
    }
    
    //Updates the Product Database with the new Product Record as per the user needs using the modifyButton
    @FXML
    public void switchToModify() throws IOException {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Products.db")) {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Product SET PRODUCTID = ?, PRODUCTNAME = ?, PRODUCTDESCRIPTION = ?, CATEGORY = ?, STOCKLEVEL = ?, PRICE = ? WHERE PRODUCTID = ? ");
            stmt.setString(1, productIdText.getText());
            stmt.setString(2, productNameText.getText());
            stmt.setString(3, productDescriptionText.getText());
            stmt.setString(4, categoryText.getText());
            stmt.setInt(5, Integer.parseInt(stockLevelText.getText()));
            stmt.setFloat(6,Float.parseFloat(priceText.getText()));
            stmt.setString(7, productIdText.getText());
            stmt.execute();
            initialize();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    // Remove Product Record FROM Product Database & TableView when deleteButton is clicked
    @FXML
    public void switchToDelete() throws IOException {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Products.db")) 
        {
            Product selectedProduct = products.getSelectionModel().getSelectedItem();
            String productID = selectedProduct.getProductID();
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM Product WHERE PRODUCTID = ? ");
            stmt.setString(1, productID);
            stmt.execute();
            initialize();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Functionality to Edit Cell Values in TableView
    @FXML
    public void editChanged() {
        productID.setCellFactory(TextFieldTableCell.forTableColumn());
        
        productID.setOnEditCommit (event -> {
        Product product = event.getRowValue();
        product.setProductID(event.getNewValue());
        updateData("productID", event.getNewValue(), product.getProductID());
    });
        productName.setCellFactory(TextFieldTableCell.forTableColumn());
        
        productName.setOnEditCommit (event -> {
        Product product = event.getRowValue();
        product.setProductName(event.getNewValue());
        updateData("productName", event.getNewValue(), product.getProductID());
    });
        productDescription.setCellFactory(TextFieldTableCell.forTableColumn());
        
        productDescription.setOnEditCommit (event -> {
        Product product = event.getRowValue();
        product.setProductDescription(event.getNewValue());
        updateData("productDescription", event.getNewValue(), product.getProductID());
    });
        category.setCellFactory(TextFieldTableCell.forTableColumn());
        
        category.setOnEditCommit (event -> {
        Product product = event.getRowValue();
        product.setCategory(event.getNewValue());
        updateData("category", event.getNewValue(), product.getProductID());
    });
        stockLevel.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
        
        stockLevel.setOnEditCommit (event -> {
        Product product = event.getRowValue();
        product.setStockLevel(event.getNewValue());
        updateData("stockLevel", event.getNewValue().toString(), product.getProductID());
    });
        price.setCellFactory(TextFieldTableCell.forTableColumn(new FloatStringConverter()));
        price.setOnEditCommit (event -> {
        Product product = event.getRowValue();
        product.setPrice(event.getNewValue());
        updateData("price", event.getNewValue().toString(), product.getProductID());
    });        
    }
    
    // Update the Product Database when there is an change to cellValue in TableView
    @FXML
    public void updateData(String column, String newValue, String productID) {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Products.db")) 
        {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Product SET "+column+" = ? WHERE PRODUCTID = ? ");
            stmt.setString(1, newValue);
            stmt.setString(2, productID);
            stmt.execute();
            initialize();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        }
}
