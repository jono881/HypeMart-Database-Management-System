
package smokegm.infs2605;

public class User
{
    private String username;
    private String password;
    private int isSupplier;
    
    public User()
    {
    }
    public User(String username, String password, int isSupplier)
    {
        this.username = username;
        this.password = password;
        this.isSupplier = isSupplier;
    }
    
    public String getUsername()
    {
        return this.username;
    }
    public String getPassword()
    {
        return this.password;
    }
    public int getIsSupplier()
    {
        return this.isSupplier;
    }
    public void setUsername(String username)
    {
        this.username = username;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    public void setIsSupplier(int isSupplier)
    {
        this.isSupplier = isSupplier;
    }
}
