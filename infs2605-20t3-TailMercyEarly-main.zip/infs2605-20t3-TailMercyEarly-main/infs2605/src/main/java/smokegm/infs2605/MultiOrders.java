package smokegm.infs2605;

public class MultiOrders {

    private String supplierName;
    private String productName;
    private int productQuantity;

    public MultiOrders() {

    }

    public MultiOrders(String supplierName, String productName, int productQuantity) {
        this.supplierName = supplierName;
        this.productName = productName;
        this.productQuantity = productQuantity;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public String getProductName() {
        return productName;
    }

    public int getProductQuantity() {
        return productQuantity;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }

}
