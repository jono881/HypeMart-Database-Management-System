
package smokegm.infs2605;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Label;

public class LoginController 
{
    @FXML private TextField usernameField; //login username
    @FXML private PasswordField passwordField; //login password
    @FXML private Label loginError;
    private String loginusername;
    private int userID;
    
    @FXML
    private void loginAttempt() throws IOException, SQLException 
    {
        Statement st;
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Users.db")) 
        {
            //Checks if username and password match those on database
            st = conn.createStatement();
            String enteredname = usernameField.getText();
            String enteredpassword = passwordField.getText();
            String query = "SELECT * FROM User WHERE USERNAME = '" + enteredname + "' and PASSWORD = '" + enteredpassword + "'";
            ResultSet rs = st.executeQuery(query);
            if (rs.next())
            {
                //gets isSupplier field from the user table. this field is basically a userID
                String getIDQuery = "SELECT ISSUPPLIER FROM User WHERE USERNAME = '" + enteredname + "' and PASSWORD = '" + enteredpassword + "'";
                rs = st.executeQuery(getIDQuery);
                loginusername = enteredname;
                userID = rs.getInt(1);
                conn.close();
                st.close(); 
                
                
                File details = new File("details.txt"); //clears then writes username and userID to a temporary file for other pages to access
                details.delete();
                details.createNewFile(); 
                FileWriter fwdetails = new FileWriter("details.txt");
                BufferedWriter bwdetails = new BufferedWriter(fwdetails);
                bwdetails.write(loginusername);
                bwdetails.newLine();
                bwdetails.write(Integer.toString(userID));
                bwdetails.close();
                if (userID == 0)
                {
                    App.setRoot("home"); //brings users to homepage
                }
                else
                {
                    App.setRoot("supplierhome");
                }
            }
            else
            {
                loginError.setVisible(true);
            }
        }
        st.close();

    }
    
    public void initialize()
    {
        File details = new File("details.txt");
        details.delete();
    }
    
    public String getLoginUsername()
    {
        return this.loginusername;
    }
    
    //Devtest function to skip login
    //Commented out in final build
    /*@FXML
    private void bypass() throws IOException
    {
        File details = new File("details.txt"); //clears then writes username and userID to a temporary file for other pages to access
        details.delete();
        details.createNewFile();
        FileWriter fwdetails = new FileWriter("details.txt");
        BufferedWriter bwdetails = new BufferedWriter(fwdetails);
        bwdetails.write("DEVMODE");
        bwdetails.newLine();
        bwdetails.write(Integer.toString(0));
        bwdetails.close();
        App.setRoot("home");
    }*/
}

