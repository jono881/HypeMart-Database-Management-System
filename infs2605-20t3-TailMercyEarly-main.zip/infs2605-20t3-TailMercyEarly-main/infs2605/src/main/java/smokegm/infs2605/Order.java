package smokegm.infs2605;

public class Order {

    private String orderID;
    private String productName;
    private String supplierID;
    private int quantity;
    private String orderStatus;
    private String orderTimeStamp;
    private String editedBy;

    public Order() {
    }

    public Order(String orderID, String productName, String supplierID, int quantity, String orderStatus, String orderTimeStamp, String editedBy) {
        this.orderID = orderID;
        this.productName = productName;
        this.supplierID = supplierID;
        this.quantity = quantity;
        this.orderStatus = orderStatus;
        this.orderTimeStamp = orderTimeStamp;
        this.editedBy = editedBy;
    }

    public String getOrderID() {
        return orderID;
    }

    public String getProductName() {
        return productName;
    }

    public String getSupplierID() {
        return supplierID;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public String getOrderTimeStamp() {
        return orderTimeStamp;
    }

    public String getEditedBy() {
        return editedBy;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public void setOrderTimeStamp(String orderTimeStamp) {
        this.orderTimeStamp = orderTimeStamp;
    }

    public void setEditedBy(String editedBy) {
        this.editedBy = editedBy;
    }

  
    
}
