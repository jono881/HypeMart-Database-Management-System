module smokegm.infs2605 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens smokegm.infs2605 to javafx.fxml;
    exports smokegm.infs2605;
    requires org.apache.commons.io;
}
