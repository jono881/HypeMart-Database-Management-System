# infs2605-20t3-TailMercyEarly
infs2605-20t3-TailMercyEarly

## General Tips
- ~~Since I don't discriminate against those with room temperature IQ, I'll provide a brief guide to using the program.~~ Login by entering a username and password (list found below on Fig 1.1) then clicking the login button. You will either arrive on the supplier dashboard or store dashboard depending on your user credentials. From here, you can edit the various tables and access functions which constitute the marking criteria to the store. Once you are satisfied with whatever you're doing, click the logout button in the top right to return to the login screen, then close the program.
- When you edit the TableViews in each of the product pages, you can either edit using the editing bar on the bottom of the page, or you can double click an individual cell to edit (hit enter to save changes if using doubleclick method).
- You can reset all the databases to default values by logging in, navigating to the help button and clicking the reset button.
- Orders can be filtered on the store user dashboard and orders page by using the ComboBox to select which column to filter by, then inputing a search filter into the searchbar.
- All the columns in the tableviews are resizable
- Even though the font used in our program isn't particularly exotic (it's only Cambria), some people (especially Mac users) may have trouble loading the font and may see ugly arial styled text. A workaround would be to install the Cambria font, but I don't expect you to do this just to mark an assignment.

## Login and Different Types of Users
We have one login screen for both the supplier and store users of the program. The program will either redirect you to the full store dashboard or a limited dashboard depending on whether the login credentials you have supplied are for a store or supplier user.

![List of Logins](https://github.com/infs2605teachingteam/infs2605-20t3-TailMercyEarly/blob/newmain(testing)/logins.JPG?raw=true)

*Fig 1.1 List of usable username and passwords for logging into our program*

The username and password fields of the table are self explanatory (I hope), and you can enter them to login on our program. The ISSUPPLIER column indicates what type of user a particular row is. A value of 0 indicates a store user which has access to the full program (you will need to login with one of these to mark the majority of the program). Any other numeric value indicates a supplier user which works for a company with an ID equal to that numeric value. They will only be able to see a limited dashboard with only the orders placed for their company. Furthermore, they are only able to edit the order status, and can do so by doubleclicking the cell which they want to edit in the Tableview.


## FAQ
**Question**: Why can we not edit users?

**Answer**: Because it wasn't in the assignment requirements, and it would be a pain to allow for editing of users. Hence, we instead provide a large preexisting list of users which should be more than enough for marking purposes. If you are feeling creative, you can manually add users to the User table of our database using a database file editor such as DB Browser for SQLite.

**Question**: Why is this document so passive aggressive?

**Answer**: It isn't. You're delusional.

#### DISCLAIMER
Our guarantee of a complete and functional assignment free from defects is rendered void if the USER table has been tampered with. We (the authors of this program) accept no liabilities for issues which may arise during marking from improper or third party modifications to the USER table.

#### DISCLAIMER v2
We have attempted to make a functioning AF 5.2, but we weren't able to get it completely working. Remenants of our most successful attempt at this AF have been left in the program. 
