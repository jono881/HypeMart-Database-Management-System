# infs2605-20t3-StonePersuasionSport
infs2605-20t3-StonePersuasionSport

## Run
The codebase runs fine on both macOS and Windows. Please ensure that you **Clean and Build** in NetBeans before attempting to run.

## Significant files
* `App.java` - JavaFX main class.
* `Database.java` - helper class to manage the SQLite JDBC connection so that no other class has to.
*  MVC "model" class:
   - `Orders.java` 
   - `DisplayOrder.java` 
   - `OrderDetails.java` 
   - `OrderUpdates.java`
   - `Product.java`
   - `Store.java`
   - `Supplier.java`
   - `SupplierUser.java`
   - `User.java`   
* MVC "view" file:
   - `About.fxml` 
   - `CreateNewOrder.fxml`
   - `Dashboard.fxml`
   - `EditOrderPopUp.fxml`
   - `LoginScreen.fxml`
   - `OrderHistory.fxml`
   - `SupplierDashboard.fxml`
   - `SupplierList.fxml`
   - `UpdateStatus.fxml`
   
*  MVC "controller" class:
   - `AboutController.java`
   - `CreateNewOrderController.java` 
   - `DashboardController.java` 
   - `EditOrderController.java` 
   - `LoginScreenController.java` 
   - `OrderHistoryController.java` 
   - `SupplierController.java` 
   - `SupplierDashboardController.java`
   - `UpdateStatusController.java`
   



## Sample login credentials

 -  **Username    -     Password      -   User type**
1. jsmith - monday -  Store 
1. mjones - tuesday - Store 
1. szhang - wednesday - Supplier
1. asprings   - thursday   - Supplier
1. bwilliams - friday - Store 
1. cturner - saturday - Store
1. dwang - sunday - Supplier         
1. echen - january -  Supplier         
1. fzhu - february - Store       
1. gford - march  - Store

## Instructions
1. **Attention:**
If the app breaks, please close it and clean and build, then rerun it. Thank you.

1. First, you log in to the app with one of the sample login credentials and select the user type ( supplier or store user). For example:
 ![Log in](docs/login.png).
 
1. In the dashboard, you can enter any keywords related to product name or status in the search field. The pie chart can change colour if you press it. 
  ![filter](docs/filter.png).

1. To add a new supplier, you need to input the supplier’s name, phone number, address and press Add button.
  ![add](docs/addsupplier.png).


1. - To edit any supplier, select the record first then click Edit button then double click the filed you want to edit it. Please press **Enter** after editing. 
     **Note:** you should keep phone number in the number format when editing it.

   - Same for deleting, select the target record first then click Delete button.
  ![edit](docs/edit.png).
  
1. To create a new order: first, click on *Create New Order* button. Then select your desired supplier and click on Choose. Select your product and press Add. Select and add products as many as you wish. To create another new order, press *Create New Order* button and repeat the process. 
   ![multi](docs/multiproduct.png).

1. - You can check your latest order at the bottom of the order history.
   ![check](docs/checkhistory.png).
   - To see the specific order information: go to the the dashboard, it displays at the bottom of the order table.
   ![orderB](docs/dashboardB.png).


1. To edit or delete order: select the record first then click on Edit or Delete.
   ![editO](docs/editOrder.png).


1. Log in as a supplier, you can select then Edit status.
   ![update](docs/updateS.png).
   
1. After viewing the About screen, you can only *log out*.
   ![about](docs/about2.png).






