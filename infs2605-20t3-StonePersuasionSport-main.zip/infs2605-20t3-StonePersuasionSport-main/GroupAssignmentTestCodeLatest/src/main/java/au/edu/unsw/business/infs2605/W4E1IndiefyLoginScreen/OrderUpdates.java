/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

/**
 *
 * @author allyanatrajano
 */
public class OrderUpdates {
    
    private String order_id;
    private String user_id;
    private String update_timestamp;
    private String full_name;


    public OrderUpdates(String order_id, String user_id, String update_timestamp, String full_name) {
        this.order_id = order_id;
        this.user_id = user_id;
        this.update_timestamp = update_timestamp;
        this.full_name = full_name;
       
    }   

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUpdate_timestamp() {
        return update_timestamp;
    }

    public void setUpdate_timestamp(String update_timestamp) {
        this.update_timestamp = update_timestamp;
    }    

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }


   
    
    
}
