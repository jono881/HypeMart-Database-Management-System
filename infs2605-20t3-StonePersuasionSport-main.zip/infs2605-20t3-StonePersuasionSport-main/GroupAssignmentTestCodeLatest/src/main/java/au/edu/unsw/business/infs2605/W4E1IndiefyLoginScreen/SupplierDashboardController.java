/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

/**
 *
 * @author allyanatrajano
 */

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.stage.WindowEvent;


public class SupplierDashboardController implements Initializable {

    Database database = new Database();
    
    @FXML
    TableView<Orders> table_orders;
    
    @FXML
    TableView<OrderUpdates> table_order_updates;
    
    @FXML
    TableColumn<Orders, String> col_order_id;
    
    @FXML
    TableColumn<Orders, String> col_supplier_id;
    
    @FXML
    TableColumn<Orders, String> col_status;
    
    @FXML
    TableColumn<Orders, String> col_order_timestamp;

    @FXML
    TableColumn<OrderUpdates, String> col_update_order_id;
    
    @FXML
    TableColumn<OrderUpdates, String> col_update_timestamp;
    
    @FXML
    TableColumn<OrderUpdates, String> col_update_user_id;
        
    @FXML
    private Button editOrderButton;
    
    @FXML
    private Button loadOrderButton;
    
    @FXML
    private Button loadUpdateButton;  
    
    @FXML
    private Label supplierIdLabel;
    
    @FXML
    private Label testLabel;    
    
    
    @FXML
    public void initialize(URL location, ResourceBundle resources) {
      
    }  
    
    
    //set supplier label to supplier_id
    @FXML
    public void printSupplierId(String supplierId){
        supplierIdLabel.setText(supplierId);
    } 
    
    @FXML
    public void editButton(ActionEvent event)throws IOException, SQLException{
        System.out.println("PRESS EDIT TEST");
    }
    
    //print Order Table based on Supplier Login
    @FXML
    public void printOrderTable(){
        ObservableList<Orders> orderList = FXCollections.observableArrayList();

            try{ 
                orderList = database.getOrdersSupplier(supplier_id);

                table_orders.setItems(orderList);
                col_order_id.setCellValueFactory(new PropertyValueFactory<>("order_id"));
                col_supplier_id.setCellValueFactory(new PropertyValueFactory<>("supplier_id"));
                col_status.setCellValueFactory(new PropertyValueFactory<>("status"));
                col_order_timestamp.setCellValueFactory(new PropertyValueFactory<>("order_timestamp"));          

            }
            catch(SQLException e){
                e.printStackTrace();
            }                
    }
    
    //print Order Updates Table based on Supplier Login
    @FXML
    public void printUpdateTable(){ 
            ObservableList<OrderUpdates> orderUpdatesList = FXCollections.observableArrayList();

           try{ 
                orderUpdatesList = database.getOrderUpdates();

                table_order_updates.setItems(orderUpdatesList);
                col_update_order_id.setCellValueFactory(new PropertyValueFactory<>("order_id"));
                col_update_user_id.setCellValueFactory(new PropertyValueFactory<>("full_name"));
                col_update_timestamp.setCellValueFactory(new PropertyValueFactory<>("update_timestamp"));
                

           }
           catch(SQLException e){
                e.printStackTrace();
           }    
    } 
    
    //pull data from Log in and print tables
    private String supplier_id;
    private String user_id;
    SupplierUser user;
    public void initData(SupplierUser supplier){
        supplier_id = supplier.getSupplier_id();
        user = supplier;
        user_id = supplier.getUser_id();
        printOrderTable();
        printUpdateTable();
        
    }  
    


    //EDIT PRODUCT
    @FXML
    public void handleEditOrdersButton(ActionEvent event)throws IOException, SQLException{
        Orders orders = table_orders.getSelectionModel().getSelectedItem();
        
        FXMLLoader loader = new FXMLLoader(getClass().getResource("UpdateStatus.fxml"));
        Parent root1 = (Parent)loader.load();
        
        UpdateStatusController updateStatusController = loader.getController();
        updateStatusController.printOrderId(orders.getOrder_id());
        updateStatusController.initDataOrder(orders);
        updateStatusController.initDataUser(user);
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        
        stage.setHeight(400);
        stage.setWidth (400);
        
        stage.show();
        
        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            public void handle(WindowEvent we)  {
                try{ 
                    ObservableList<Orders> orderList = FXCollections.observableArrayList();                   
                    orderList = database.getOrdersSupplier(supplier_id);

                    table_orders.setItems(orderList);
                    col_order_id.setCellValueFactory(new PropertyValueFactory<>("order_id"));
                    col_supplier_id.setCellValueFactory(new PropertyValueFactory<>("supplier_id"));
                    col_status.setCellValueFactory(new PropertyValueFactory<>("status"));
                    col_order_timestamp.setCellValueFactory(new PropertyValueFactory<>("order_timestamp")); 
                    
                    ObservableList<OrderUpdates> orderUpdatesList = FXCollections.observableArrayList();                    
                    orderUpdatesList = database.getOrderUpdates();

                    table_order_updates.setItems(orderUpdatesList);
                    col_update_order_id.setCellValueFactory(new PropertyValueFactory<>("order_id"));
                    col_update_user_id.setCellValueFactory(new PropertyValueFactory<>("full_name"));
                    col_update_timestamp.setCellValueFactory(new PropertyValueFactory<>("update_timestamp"));

                }
                catch(SQLException e){
                    e.printStackTrace();
                }  
            }
        }); 

        
    }  
    
    
    //LOG OUT BUTTON
    @FXML
    private void handleNavigationLogout(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("LoginScreen.fxml"));
        Parent root1 = (Parent)loader.load();
        Scene scene = new Scene(root1);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    } 
    //Supplier About
    @FXML
    private void handleNavigationAbout(ActionEvent event) throws IOException {
       FXMLLoader loader = new FXMLLoader(getClass().getResource("About2.fxml"));
        Parent root1 = (Parent)loader.load();
        Scene scene = new Scene(root1);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    } 
    
    
}


    
