package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;


public class LoginScreenController implements Initializable {
    
    Database database = new Database();

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    
    @FXML
    private ComboBox userLevel;
    
    
    //Log in Button
    @FXML
    private void handleLoginButtonAction(ActionEvent event) throws IOException, SQLException{
        System.out.println("clicked");
        String username = usernameField.getText().trim();
        String password = passwordField.getText();
        String userlevel = (String) userLevel.getValue();

        if (usernameField.getText().isEmpty()||passwordField.getText().isEmpty()){
            Alert alert1 = new Alert(Alert.AlertType.WARNING);
            alert1.setTitle("Incomplete Field");
            alert1.setContentText("You must enter a username and password");
            alert1.setHeaderText(null);
            alert1.showAndWait(); 
        }
        else if(userLevel.getValue() == null){
            Alert alert1 = new Alert(Alert.AlertType.WARNING);
            alert1.setTitle("Incomplete Field");
            alert1.setContentText("You must select a user type");
            alert1.setHeaderText(null);
            alert1.showAndWait();            
        }

        else{
            boolean success = database.login(username, password, userlevel); 

            if (userlevel.equals("Store Login")){
                if (success) {
                    App.setRoot("Dashboard");
                } 
                else {
                    Alert alert1 = new Alert(Alert.AlertType.WARNING);
                    alert1.setTitle("Incorrect Login Details");
                    alert1.setContentText("Incorrect username or password");
                    alert1.setHeaderText(null);
                    alert1.showAndWait(); 
                }      
            }

            else{

                if (success) {   

                    SupplierUser supplier = new SupplierUser(database.getUserId(username), database.getSupplierIdFromUsername(username), database.getSupplierNameFromUsername(username));
                    setSupplierDashboard(supplier, event);
                    App.setRoot("SupplierDashboard");

                } 
                else {
                    Alert alert1 = new Alert(Alert.AlertType.WARNING);
                    alert1.setTitle("Incorrect Login Details");
                    alert1.setContentText("Incorrect username or password");
                    alert1.setHeaderText(null);
                    alert1.showAndWait(); 
                }              
            }
            
        }
    }

    @FXML
    public void initialize(URL location, ResourceBundle resources) {
        userLevel.getItems().add("Store Login");
        userLevel.getItems().add("Supplier Login");
    }
    
    @FXML
    public String getSupplierId(String username)throws SQLException{
        String user_id = database.getUserId(username);
        String supplier_id = database.getSupplierId(user_id);
        
        return supplier_id;   
    }

    // switch to supplier dashboard
    @FXML
    public void setSupplierDashboard(SupplierUser supplier, ActionEvent event) throws IOException {
              
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SupplierDashboard.fxml"));
        Parent root1 = (Parent)loader.load();
        SupplierDashboardController supplierDashboardController = loader.getController();
        supplierDashboardController.printSupplierId(supplier.getSupplier_name()); 
        supplierDashboardController.initData(supplier);

        Scene scene = new Scene(root1);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();

    }      
    
   
}
