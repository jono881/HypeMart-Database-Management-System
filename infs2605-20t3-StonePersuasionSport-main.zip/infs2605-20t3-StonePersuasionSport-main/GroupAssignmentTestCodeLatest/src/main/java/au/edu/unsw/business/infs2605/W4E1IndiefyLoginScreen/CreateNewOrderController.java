/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

/**
 *
 * @author allyanatrajano
 */

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class CreateNewOrderController {
    
    Database database = new Database();
    
    @FXML
    TableView<DisplayProduct> table_orders;
    
    @FXML
    TableColumn<DisplayProduct, String> col_product_id;

    
    @FXML
    TableColumn<DisplayProduct, String> col_quantity;
    
    @FXML
    TableColumn<DisplayProduct, String> col_product_name; 
    
    @FXML
    TableView<Supplier> table_supplier;
    
    @FXML
    TableColumn<Supplier, String> col_supplier_id;

    @FXML
    TableColumn<Supplier, String> col_supplier_name;
    
    @FXML
    TableView<Product> table_product;
    
    @FXML
    TableColumn<Product, String> col_prod_id;

    @FXML
    TableColumn<Product, String> product_name;    

    @FXML
    TableColumn<Product, String> product_price;  
    
    @FXML
    TableColumn<Product, String> product_type; 
    
    @FXML
    private Button addSupplierButton;
    
    @FXML
    private Button addProductButton;
    
    @FXML
    private Button editOrderButton;
    
    @FXML
    private Button deleteOrderButton;
    
    @FXML
    private Label orderLabel;

    @FXML
    private Label chooseSupplierLabel;
    
    @FXML
    private Button orderHistoryButton;  
    
    @FXML
    private Button dashboardButton;
    
    @FXML
    private Button supplierButton;
    
    @FXML
    private Button aboutButton;
    
    @FXML
    private Button helpButton;
    
    @FXML
    private Button settingsButton;
    
    @FXML
    private Button logOutButton;
    
    @FXML
    private Button neworder;
    
    private int order_id;

    @FXML
    public void initialize() {
        
        try{

            ObservableList<Supplier> supplierList = FXCollections.observableArrayList();
            supplierList = database.getSupplier();

            table_supplier.setItems(supplierList);
            col_supplier_id.setCellValueFactory(new PropertyValueFactory<>("supplier_id"));
            col_supplier_name.setCellValueFactory(new PropertyValueFactory<>("supplier_name"));

            ObservableList<Product> productList = FXCollections.observableArrayList();
            productList = database.getProduct();

            table_product.setItems(productList);
            col_prod_id.setCellValueFactory(new PropertyValueFactory<>("product_id"));
            product_name.setCellValueFactory(new PropertyValueFactory<>("product_name"));        
            product_price.setCellValueFactory(new PropertyValueFactory<>("price"));
            product_type.setCellValueFactory(new PropertyValueFactory<>("product_type"));
           
            //Set Product and Quantity cell editable
            table_orders.setEditable(true);
            DisplayProduct orderDetails = table_orders.getSelectionModel().getSelectedItem();
            col_product_id.setCellFactory(TextFieldTableCell.forTableColumn()); 
            col_quantity.setCellFactory(TextFieldTableCell.forTableColumn());
        }
        catch(SQLException e){
            
        }
        
    }
    

    //CHANGE SCREENS
    @FXML
    private void handleNavigationDashboard(ActionEvent event) throws IOException {
        App.setRoot("Dashboard");
    }
    
    @FXML
    private void handleNavigationOrderHistory(ActionEvent event) throws IOException {
        App.setRoot("OrderHistory");
    }   
        
    @FXML
    private void handleNavigationSupplier(ActionEvent event) throws IOException {
        App.setRoot("SupplierList");
    }  

    @FXML
    private void handleNavigationAbout(ActionEvent event) throws IOException {
        App.setRoot("About");
    } 
    
    @FXML
    private void handleNavigationLogout(ActionEvent event) throws IOException {
        App.setRoot("LoginScreen");
    }    
    
    
    //ADD SUPPLIER
    private String supplier_id;
    
    @FXML
    private void handleChooseSupplierButton(ActionEvent event) throws IOException, SQLException{
        
        if (orderLabel.getText().isEmpty()){
            Alert alert1 = new Alert(Alert.AlertType.WARNING);
            alert1.setTitle("Incomplete Fields");
            alert1.setContentText("You need to click Create New Order");
            alert1.setHeaderText(null);
            alert1.showAndWait();              
        }
        else{
            Supplier supplier = table_supplier.getSelectionModel().getSelectedItem();     

            supplier_id = supplier.getSupplier_id();
            database.addOrder(supplier.getSupplier_id());

            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert1.setTitle("Successful");
            alert1.setContentText("You chose " + supplier.getSupplier_name());
            alert1.setHeaderText(null);
            alert1.showAndWait();  
        }
            
    }    
    
    //ADD SUPPLIER
    @FXML
    private void handleAddProductButton(ActionEvent event) throws IOException, SQLException{

        if (orderLabel.getText().isEmpty()){
            Alert alert1 = new Alert(Alert.AlertType.WARNING);
            alert1.setTitle("Incomplete Fields");
            alert1.setContentText("You need to click Create New Order");
            alert1.setHeaderText(null);
            alert1.showAndWait();              
        }
        else if (supplier_id == null){
            Alert alert1 = new Alert(Alert.AlertType.WARNING);
            alert1.setTitle("Incomplete Fields");
            alert1.setContentText("You need to choose a supplier");
            alert1.setHeaderText(null);
            alert1.showAndWait();               
        }
        else{
            Product product = table_product.getSelectionModel().getSelectedItem(); 

            FXMLLoader loader = new FXMLLoader(getClass().getResource("EditQuantity.fxml"));
            Parent root1 = (Parent)loader.load();

            EditQuantityController editQuantityController = loader.getController();
            editQuantityController.initData(product);
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));

            stage.setHeight(400);
            stage.setWidth (400);

            stage.show();

            stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                public void handle(WindowEvent we)  {
                    try{
                    ObservableList<DisplayProduct> orderDetailsList = FXCollections.observableArrayList();
                    orderDetailsList = database.getOrderDetails(Integer.toString(order_id));

                    table_orders.setItems(orderDetailsList);
                    col_product_id.setCellValueFactory(new PropertyValueFactory<>("product_id"));
                    col_quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
                    col_product_name.setCellValueFactory(new PropertyValueFactory<>("product_name"));

                    }
                    catch (SQLException e){
                        e.printStackTrace();
                    }
                }
            });          
        }    
    }
    
    
    //EDIT ORDERS
    @FXML
    public void onEditOrderProduct_id(TableColumn.CellEditEvent<OrderDetails,String> ordersStringCellEditEvent)throws IOException, SQLException{
       DisplayProduct orderDetails = table_orders.getSelectionModel().getSelectedItem();
       orderDetails.setProduct_id(ordersStringCellEditEvent.getNewValue());
       database.editOrderProduct_id(orderDetails.getOrder_id(),ordersStringCellEditEvent.getNewValue());
       //debugging
       System.out.println("successfully edited product_id");
       database.printOrder();
    } 
    
    @FXML
    public void onEditOrderQuantity(TableColumn.CellEditEvent<OrderDetails,String> ordersStringCellEditEvent)throws IOException, SQLException{
       DisplayProduct orderDetails = table_orders.getSelectionModel().getSelectedItem();
       orderDetails.setQuantity(ordersStringCellEditEvent.getNewValue());
       database.editOrderQuantity(orderDetails.getOrder_id(),ordersStringCellEditEvent.getNewValue());
       //debugging
       System.out.println("successfully edited quantity");
       database.printOrder();
    } 
    
    //DELETE PRODUCTS FROM ORDER
    @FXML
    public void handleDeleteProductButton(ActionEvent event)throws IOException, SQLException{
        //Alert
        Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
        alert1.setTitle("Are you sure?");        
        alert1.setContentText("Are you sure you want to delete this product?");
        alert1.setHeaderText(null);
        alert1.showAndWait();    
        
        DisplayProduct orderDetails = table_orders.getSelectionModel().getSelectedItem();
        table_orders.getItems().remove(orderDetails);
        database.deleteOrderDetails(orderDetails.getProduct_id());
    }
    
    //RELOAD PAGE FOR NEW ORDER
    @FXML
    public void handleNewOrderButton(ActionEvent event)throws IOException, SQLException{

    table_orders.getItems().clear();
    order_id = Integer.parseInt(database.getOrder_id()) + 1;
    orderLabel.setText(Integer.toString(order_id));   
    initialize();
    }    
  


    
}
