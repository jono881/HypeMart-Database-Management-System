/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

/**
 *
 * @author allyanatrajano
 */

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.control.Alert;

public class OrderHistoryController implements Initializable {
    
    Database database = new Database();
    
    @FXML
    TableView<Orders> table_orders;
    
    @FXML
    TableColumn<Orders, String> col_order_id;
    
    @FXML
    TableColumn<Orders, String> col_supplier_id;
    
    @FXML
    TableColumn<Orders, String> col_status;
    
    @FXML
    TableColumn<Orders, String> col_order_timestamp;
    
    @FXML
    private Button editOrderButton;
    
    @FXML
    private Button deleteButton;

    
    //CHANGE SCREEN
    @FXML
    private void handleNavigationCreateNewOrder(ActionEvent event) throws IOException {
        App.setRoot("CreateNewOrder");
    }
    
    @FXML
    private void handleNavigationDashboard(ActionEvent event) throws IOException {
        App.setRoot("Dashboard");
    }
           
    @FXML
    private void handleNavigationSupplier(ActionEvent event) throws IOException {
        App.setRoot("SupplierList");
    }  

    @FXML
    private void handleNavigationAbout(ActionEvent event) throws IOException {
        App.setRoot("About");
    }  
    
    @FXML
    private void handleNavigationLogout(ActionEvent event) throws IOException {
        App.setRoot("LoginScreen");
    }         
    
    @FXML
    public void initialize(URL location, ResourceBundle resources){
        ObservableList<Orders> orderList = FXCollections.observableArrayList();
       try{ 
            orderList = database.getOrders();
        
            table_orders.setItems(orderList);
            col_order_id.setCellValueFactory(new PropertyValueFactory<>("order_id"));
            col_supplier_id.setCellValueFactory(new PropertyValueFactory<>("supplier_id"));
            col_status.setCellValueFactory(new PropertyValueFactory<>("status"));
            col_order_timestamp.setCellValueFactory(new PropertyValueFactory<>("order_timestamp"));
       }
       catch(SQLException e){
            e.printStackTrace();
       }
    }
   
    //EDIT ORDERS
    @FXML
    public void handleEditOrdersButton(ActionEvent event)throws IOException, SQLException{
        Orders orders = table_orders.getSelectionModel().getSelectedItem();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("EditOrderPopUp.fxml"));
        Parent root1 = (Parent)loader.load();
        
        EditOrderController editController = loader.getController();
        editController.printOrderId(orders.getOrder_id());
        editController.initData(orders);
        
        Stage stage = new Stage();
        stage.setTitle("Second Window");
        stage.setScene(new Scene(root1));
        

        stage.show();
        

    }
    
    //GET ORDER ID FROM SELECTED ORDER
    @FXML
    public String getOrderId(){
        Orders orders = table_orders.getSelectionModel().getSelectedItem();
        return orders.getOrder_id();    
    }
   
    //DELETE ORDERS
    @FXML
    public void handleDeleteOrdersButton(ActionEvent event)throws IOException, SQLException{
        //Alert
        Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
        alert1.setTitle("Are you sure?");        
        alert1.setContentText("Are you sure you want to delete this order?");
        alert1.setHeaderText(null);
        alert1.showAndWait();            
        
        Orders orders = table_orders.getSelectionModel().getSelectedItem();
        table_orders.getItems().remove(orders);
        database.deleteOrders(orders.getOrder_id());
    }
    
    
    
}
