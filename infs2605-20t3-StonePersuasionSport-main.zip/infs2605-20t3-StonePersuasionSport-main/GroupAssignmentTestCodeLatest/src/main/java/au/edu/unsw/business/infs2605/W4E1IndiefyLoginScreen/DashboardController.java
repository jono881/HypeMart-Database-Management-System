/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

/**
 *
 * @author allyanatrajano
 */

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.geometry.Side;
import javafx.scene.chart.PieChart;

public class DashboardController {
    
    Database database = new Database();    
    
    @FXML
    private Button dashboardButton;
    
    @FXML
    private Button supplierButton;
    
    @FXML
    private Button createNewOrderButton;
    
    @FXML
    private Button orderHistoryButton;
    
    @FXML
    private Button aboutButton;
    
    @FXML
    private Button helpButton;
    
    @FXML
    private Button settingsButton;
    
    @FXML
    private Button logOutButton;
    
    
    @FXML
    TableView<DisplayOrder> table_display_order;
  
    @FXML
    TableColumn<DisplayOrder, String> col_order_id;
    
    @FXML
    TableColumn<DisplayOrder, String> col_product_name;
    
    @FXML
    TableColumn<DisplayOrder, String> col_quantity;
    
    @FXML
    TableColumn<DisplayOrder, String> col_status;
    
    @FXML
    TextField filterField;
   
    
     @FXML
    private PieChart pie;    
    
      
    //CHANGE SCREENS
    @FXML
    private void handleNavigationCreateNewOrder(ActionEvent event) throws IOException {
        App.setRoot("CreateNewOrder");
    }
    
    @FXML
    private void handleNavigationOrderHistory(ActionEvent event) throws IOException {
        App.setRoot("OrderHistory");
    }   
        
    @FXML
    private void handleNavigationSupplier(ActionEvent event) throws IOException {
        App.setRoot("SupplierList");
    }  

    @FXML
    private void handleNavigationAbout(ActionEvent event) throws IOException {
        App.setRoot("About");
    } 
    
    @FXML
    private void handleNavigationLogout(ActionEvent event) throws IOException {
        App.setRoot("LoginScreen");
    }     
    
    @FXML
    public void initialize() throws SQLException {
        ObservableList<DisplayOrder> orderDisplayList = FXCollections.observableArrayList();
        orderDisplayList = database.getOrderDisplay();
        
        table_display_order.setItems(orderDisplayList);
        col_order_id.setCellValueFactory(new PropertyValueFactory<>("order_id"));
        col_product_name.setCellValueFactory(new PropertyValueFactory<>("product_name"));
        col_quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        col_status.setCellValueFactory(new PropertyValueFactory<>("status"));
//filter Function
        FilteredList <DisplayOrder> filteredData =  new FilteredList <> (orderDisplayList, b->true);
        
            filterField.textProperty().addListener((observable, oldValue, newValue) ->{
                filteredData.setPredicate (table_display_order -> { 
                    if (newValue == null || newValue.isEmpty()){
                        return true;
                    }
                    String lowerCaseFilter = newValue.toLowerCase();

                    if (table_display_order.getProduct_name().toLowerCase().contains(lowerCaseFilter)) {
                        return true; // Filter matches product name.
                    } else if     (table_display_order.getStatus().toLowerCase().contains(lowerCaseFilter)) {
                        return true; // Filter matches status.
                        }
                            return false; // Does not match.           
                });
       
           });
 
    SortedList<DisplayOrder> sortedData = new SortedList<>(filteredData);
    sortedData.comparatorProperty().bind(table_display_order.comparatorProperty());
    table_display_order.setItems(sortedData);               
         
    //Pie chart  
    
         try{ 
            ResultSet placedRs = database.getResultSet("Select count(STATUS)from Orders"
                    +" Where STATUS = 'Order Placed' ;" );
            ResultSet pendingRs = database.getResultSet("Select count(STATUS) from Orders"
                    +" Where STATUS = 'Order Pending';");
            ResultSet packedRs = database.getResultSet("Select count(STATUS) from Orders"
                    +" Where STATUS = 'Order Packed';");
            ResultSet shippedRs = database.getResultSet("Select count(STATUS) from Orders"
                    +" Where STATUS = 'Order Shipped';");
            ResultSet cancelledRs = database.getResultSet("Select count(STATUS) from Orders"
                    +" Where STATUS = 'Order Cancelled';");
            
            ResultSet totalRs = database.getResultSet("Select count(STATUS) from Orders;");
           
            double total = totalRs.getDouble(1); 
            double placed =  100*placedRs.getDouble(1)/total;
            //double placed = (int) (100*placedRs.getDouble(1)/total);
//            double pending = (int) (100*pendingRs.getDouble(1)/total);
//            double packed = (int) (100*packedRs.getDouble(1)/total);
//            double shipped = (int) (100*shippedRs.getDouble(1)/total);
//            double cancelled = (int) (100*cancelledRs.getDouble(1)/total);
           
            double pending =  (100.00*pendingRs.getDouble(1)/total);
            double packed =  (100*packedRs.getDouble(1)/total);
            double shipped =  (100*shippedRs.getDouble(1)/total);
            double cancelled =  (100*cancelledRs.getDouble(1)/total);
           
            double placed1 = Math.round(placed * 100.0) / 100.0;
            double pending1 = Math.round(pending * 100.0) / 100.0;
            double packed1 = Math.round(packed * 100.0) / 100.0;
            double shipped1 = Math.round(shipped * 100.0) / 100.0;
            double cancelled1 = Math.round(cancelled * 100.0) / 100.0;


           
     
            
            pie.getData().clear();
            
            ObservableList<PieChart.Data> details = FXCollections.observableArrayList(
        
            new PieChart.Data("Order Placed",placed1),
            new PieChart.Data("Order Pending ",pending1),
            new PieChart.Data("Order Packed",packed1),
            new PieChart.Data("Order Shipped",shipped1),
            new PieChart.Data("Order Cancelled",cancelled1)
       
        ); 
            pie.setData(details);
            //pie.setTitle("Order Status");   
            pie.setLegendSide(Side.LEFT);
            pie.setLabelsVisible(true);
            pie.setClockwise(false);
            pie.setStartAngle(90);
            
       //add legend , percentage
        details.forEach(data1 ->
                data1.nameProperty().bind(
                        Bindings.concat(
                                data1.getName(), " ", data1.pieValueProperty(), " %"
                        )
                )
        ); }catch (Exception e) {
            System.out.println("not work");
            e.printStackTrace();
                     
        }
         
    }
    

}
