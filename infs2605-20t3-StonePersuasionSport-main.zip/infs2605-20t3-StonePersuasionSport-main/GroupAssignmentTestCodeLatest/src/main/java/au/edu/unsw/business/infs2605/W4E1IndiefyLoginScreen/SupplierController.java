/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldTableCell;

/**
 *
 * @author YXTing
 */
public class SupplierController {
    
    Database database = new Database();
    
    @FXML
    TableView<Supplier> table_supplier;
    
    @FXML
    TableColumn<Supplier, String> col_supplier_id;

    @FXML
    TableColumn<Supplier, String> col_supplier_name;

    @FXML
    TableColumn<Supplier, String> col_phone_no;

    @FXML
    TableColumn<Supplier, String> col_address;
    
    
    @FXML
    private TextField nameField;
    
    @FXML
    private TextField phoneNumberField;
    
    @FXML
    private TextField addressField;   
    
    @FXML
    private Button addSupplierButton;
    
    @FXML
    private Button editSupplierButton;
    
    @FXML
    private Button deleteSupplierButton;
    
    @FXML
    private Label success;
    
    @FXML
    private Label table;
    
    //CHANGE SCREENS
    @FXML
    private void handleNavigationCreateNewOrder(ActionEvent event) throws IOException {
        App.setRoot("CreateNewOrder");
    }
    
    @FXML
    private void handleNavigationOrderHistory(ActionEvent event) throws IOException {
        App.setRoot("OrderHistory");
    }   
        
    @FXML
    private void handleNavigationDashboard(ActionEvent event) throws IOException {
        App.setRoot("Dashboard");
    }  

    @FXML
    private void handleNavigationAbout(ActionEvent event) throws IOException {
        App.setRoot("About");
    } 

    @FXML
    private void handleNavigationLogout(ActionEvent event) throws IOException {
        App.setRoot("LoginScreen");
    }  
    
    @FXML
    public void initialize() throws SQLException {
        ObservableList<Supplier> supplierList = FXCollections.observableArrayList();
        supplierList = database.getSupplier();
        
        table_supplier.setItems(supplierList);
        col_supplier_id.setCellValueFactory(new PropertyValueFactory<>("supplier_id"));
        col_supplier_name.setCellValueFactory(new PropertyValueFactory<>("supplier_name"));
        col_phone_no.setCellValueFactory(new PropertyValueFactory<>("phone_number"));
        col_address.setCellValueFactory(new PropertyValueFactory<>("address"));    
        
        table_supplier.setEditable(true);
        Supplier supplier = table_supplier.getSelectionModel().getSelectedItem();
        col_supplier_name.setCellFactory(TextFieldTableCell.forTableColumn()); 
        col_phone_no.setCellFactory(TextFieldTableCell.forTableColumn());
        col_address.setCellFactory(TextFieldTableCell.forTableColumn());        
        
    }
    
    //ADD SUPPLIER
    @FXML
    private void handleAddNewSupplierButton(ActionEvent event) throws IOException, SQLException{
        String add_supplier_name = nameField.getText();
        String add_phone_number= phoneNumberField.getText();  
        String add_address = addressField.getText();
        try{
        if (nameField.getText().isEmpty() || phoneNumberField.getText().isEmpty() || addressField.getText().isEmpty()){
            Alert alert1 = new Alert(Alert.AlertType.WARNING);
            alert1.setTitle("Incomplete Field");
            alert1.setContentText("You need to enter all fields");
            alert1.setHeaderText(null);
            alert1.showAndWait();
        }        
        else{
            
            if (add_phone_number.matches("[0-9]+")){ 
                
            database.addSupplier(add_supplier_name,add_phone_number,add_address);
            //debugging
            System.out.println("successfully add new supplier");

            //display additional input in table
            ObservableList<Supplier> supplierList = FXCollections.observableArrayList();
            supplierList = database.getSupplier();
            table_supplier.setItems(supplierList);

            nameField.clear();
            phoneNumberField.clear();
            addressField.clear();

            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert1.setTitle("Successful");
            alert1.setContentText("You successfully added a new supplier");
            alert1.setHeaderText(null);
            alert1.showAndWait();            
         
            
            }
            else{
            Alert alert2 = new Alert(Alert.AlertType.WARNING);
            alert2.setTitle("Value entered is not valid");
            alert2.setContentText("You can only enter numbers in Phone Number field");
            alert2.setHeaderText(null);
            alert2.showAndWait();                
            }
        }
    }catch(Exception e) {
        System.out.println("not work");
        e.printStackTrace();
        
     }
    }
    
    //EDIT SUPPLIER  
    @FXML
    public void onEditSupplierName(TableColumn.CellEditEvent<Supplier,String> supplierStringCellEditEvent)throws IOException, SQLException{
       Supplier supplier = table_supplier.getSelectionModel().getSelectedItem();
       supplier.setSupplier_name(supplierStringCellEditEvent.getNewValue());
       database.editSupplierName(supplier.getSupplier_id(),supplierStringCellEditEvent.getNewValue());
       //debugging
       System.out.println("successfully edited supplier name");
       database.printSupplier();
    }    
    
    @FXML
    public void onEditPhoneNumber(TableColumn.CellEditEvent<Supplier,String> supplierStringCellEditEvent)throws IOException, SQLException{
       //try{
       Supplier supplier = table_supplier.getSelectionModel().getSelectedItem();
       supplier.setPhone_number(supplierStringCellEditEvent.getNewValue());
       database.editSupplierPhoneNumber(supplier.getSupplier_id(),supplierStringCellEditEvent.getNewValue());
       //debugging
       System.out.println("successfully edited supplier phonenumber");
       database.printSupplier();
//    } catch(Exception e){
//        
//    }
}
    
    @FXML
    public void onEditAddress(TableColumn.CellEditEvent<Supplier,String> supplierStringCellEditEvent)throws IOException, SQLException{
       Supplier supplier = table_supplier.getSelectionModel().getSelectedItem();
       supplier.setAddress(supplierStringCellEditEvent.getNewValue());
       database.editSupplierAddress(supplier.getSupplier_id(),supplierStringCellEditEvent.getNewValue());
       //debugging
       System.out.println("successfully edited supplier name");
       database.printSupplier();
    }      
    
    
    //DELETE ORDERS
    @FXML
    public void handleDeleteSupplierButton(ActionEvent event)throws IOException, SQLException{
        //Alert
        Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
        alert1.setTitle("Are you sure?");        
        alert1.setContentText("Are you sure you want to delete this supplier?");
        alert1.setHeaderText(null);
        alert1.showAndWait();    
        
        Supplier supplier = table_supplier.getSelectionModel().getSelectedItem();
        table_supplier.getItems().remove(supplier);
        database.deleteSupplier(supplier.getSupplier_id());
    }
    
}
