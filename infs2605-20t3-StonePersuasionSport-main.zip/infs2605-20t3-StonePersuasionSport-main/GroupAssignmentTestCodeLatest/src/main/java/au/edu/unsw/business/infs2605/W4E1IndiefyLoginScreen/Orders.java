/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

/**
 *
 * @author allyanatrajano
 */
public class Orders {

    private String order_id;
    private String supplier_id;
    private String status;
    private String order_timestamp;


    public Orders(String order_id, String supplier_id, String status, String order_timestamp) {
        this.order_id = order_id;
        this.supplier_id = supplier_id;
        this.status = status;
        this.order_timestamp = order_timestamp;

    }


    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getSupplier_id() {
        return supplier_id;
    }

    public void setSupplier_id(String supplier_id) {
        this.supplier_id = supplier_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOrder_timestamp() {
        return order_timestamp;
    }

    public void setOrder_timestamp(String order_timestamp) {
        this.order_timestamp = order_timestamp;
    }


    
    
}
