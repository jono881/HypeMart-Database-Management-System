/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

/**
 *
 * @author allyanatrajano
 */
public class DisplayOrder {

    private String order_id;
    private String product_name;
    private String quantity;
    private String status;
    
    public DisplayOrder(String order_id, String product_name, String quantity, String status){
        this.order_id = order_id;
        this.product_name = product_name;
        this.quantity = quantity;
        this.status = status;
    }        

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    
}
