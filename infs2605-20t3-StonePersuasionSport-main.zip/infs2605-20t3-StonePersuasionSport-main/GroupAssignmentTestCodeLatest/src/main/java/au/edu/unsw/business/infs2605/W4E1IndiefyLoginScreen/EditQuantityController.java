/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

/**
 *
 * @author allyanatrajano
 */


import java.io.IOException;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class EditQuantityController {
    
 Database database = new Database();   
    
    @FXML
    private TextField quantityField;  
    
    @FXML
    public void initialize(URL location, ResourceBundle resources) {
      
    }         
    
    @FXML
    public void handleSaveButton(ActionEvent event)throws IOException, SQLException{ 
        
        String quantity = quantityField.getText();
        
         if (quantity.matches("[a-zA-Z]+")){
             
            Alert alert2 = new Alert(Alert.AlertType.WARNING);
            alert2.setTitle("Value entered is not valid");
            alert2.setContentText("You can only enter numbers");
            alert2.setHeaderText(null);
            alert2.showAndWait(); 

         }
         else if(checkSpecialCharacters(quantity)){
            Alert alert2 = new Alert(Alert.AlertType.WARNING);
            alert2.setTitle("Value entered is not valid");
            alert2.setContentText("You can only enter numbers");
            alert2.setHeaderText(null);
            alert2.showAndWait();              
         }
         else if(quantityField.getText().isEmpty()){
            Alert alert2 = new Alert(Alert.AlertType.WARNING);
            alert2.setTitle("Value entered is not valid");
            alert2.setContentText("You must enter a value");
            alert2.setHeaderText(null);
            alert2.showAndWait();              
         }
         else if (quantity.equals("0")){
            Alert alert2 = new Alert(Alert.AlertType.WARNING);
            alert2.setTitle("Value entered is not valid");
            alert2.setContentText("You must enter a value above 0");
            alert2.setHeaderText(null);
            alert2.showAndWait();               
         }
         else{
            database.addToOrderDetails(database.getOrder_id(),product_id, Integer.parseInt(quantityField.getText()));   
            //debugging
            database.printOrder();


            Node node = (Node)event.getSource();
            Stage stage = (Stage)node.getScene().getWindow();
            stage.fireEvent(new WindowEvent(stage, WindowEvent.WINDOW_CLOSE_REQUEST));   
        } 
         
    }
    
    //pull Product Id
    String product_id;
    
    public void initData(Product product){
        product_id = product.getProduct_id();
    }  
    
    
    //Check for special characters
    public static boolean checkSpecialCharacters(String quantity){
        String regex = "[^0-9]+";
        Pattern p = Pattern.compile(regex); 
        Matcher m = p.matcher(quantity);
        if (m.matches()){
            return true;
        }
        else{
            return false;
        }
    }
            
}
