/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

/**
 *
 * @author allyanatrajano
 */

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldTableCell;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;

public class EditOrderController implements Initializable{
Database database = new Database();
    
    @FXML
    TableView<DisplayProduct> table_orders;
    
    @FXML
    TableColumn<DisplayProduct, String> col_product_id;

    
    @FXML
    TableColumn<DisplayProduct, String> col_quantity;

    @FXML
    TableColumn<DisplayProduct, String> col_product_name;    
    
    @FXML
    private TextField supplier_idField;  
    
    @FXML
    private TextField product_idField;
    
    @FXML
    private TextField quantityField;   
   
    
    @FXML
    private Button addProductButton;
    
    @FXML
    private Button editSupplierButton;
    
    @FXML
    private Button editProductButton;
    
    @FXML
    private Button deleteProductButton;
    
    @FXML
    private Label orderLabel;

    @FXML
    private Label supplierNoLabel;
    

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        table_orders.setEditable(true);
        DisplayProduct orderDetails = table_orders.getSelectionModel().getSelectedItem();
        col_product_id.setCellFactory(TextFieldTableCell.forTableColumn()); 
        col_quantity.setCellFactory(TextFieldTableCell.forTableColumn());
    }
    
    //pull order_id from Order History Controller
    private String order_id;

    public void initData(Orders orders){
        order_id = orders.getOrder_id();
        printTable();
    }
    
    //set Order label to Order_id
    @FXML
    public void printOrderId(String order_id){
        orderLabel.setText(order_id);
    }
    
    //print Product Table
    @FXML
    public void printTable(){
        try{
            ObservableList<DisplayProduct> orderDetailsList = FXCollections.observableArrayList();
            orderDetailsList = database.getOrderDetails(this.order_id);
            table_orders.setItems(orderDetailsList);
            col_product_id.setCellValueFactory(new PropertyValueFactory<>("product_id"));
            col_quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
            col_product_name.setCellValueFactory(new PropertyValueFactory<>("product_name"));
        }
        catch(SQLException e){
            
        }        
    }
    //EDIT PRODUCT
    
    @FXML
    public void onEditOrderProduct_id(TableColumn.CellEditEvent<OrderDetails,String> ordersStringCellEditEvent)throws IOException, SQLException{
        DisplayProduct orderDetails = table_orders.getSelectionModel().getSelectedItem();
        orderDetails.setProduct_id(ordersStringCellEditEvent.getNewValue());
        database.editOrderProduct_id(orderDetails.getOrder_id(),ordersStringCellEditEvent.getNewValue());
        
        //debugging
        System.out.println("successfully edited product_id");
        database.printOrder();

        //Alert
        Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
        alert1.setTitle("Successful");
        alert1.setContentText("You successfully edited the order");
        alert1.setHeaderText(null);
        alert1.showAndWait();           
       
    } 
    
    @FXML
    public void onEditOrderQuantity(TableColumn.CellEditEvent<OrderDetails,String> ordersStringCellEditEvent)throws IOException, SQLException{
       DisplayProduct orderDetails = table_orders.getSelectionModel().getSelectedItem();

       orderDetails.setQuantity(ordersStringCellEditEvent.getNewValue());
       database.editOrderQuantity(orderDetails.getOrder_id(),ordersStringCellEditEvent.getNewValue());
       //debugging
       System.out.println("successfully edited quantity");
       database.printOrder();
       
    }     
    
    
    //DELETE PRODUCTS FROM ORDER
    @FXML
    public void handleDeleteProductButton(ActionEvent event)throws IOException, SQLException{
        //Alert
        Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
        alert1.setTitle("Are you sure?");        
        alert1.setContentText("Are you sure you want to delete this product?");
        alert1.setHeaderText(null);
        alert1.showAndWait();     
        
        DisplayProduct orderDetails = table_orders.getSelectionModel().getSelectedItem();
        table_orders.getItems().remove(orderDetails);
        database.deleteOrderDetails(orderDetails.getProduct_id());
              
    }
}
    
