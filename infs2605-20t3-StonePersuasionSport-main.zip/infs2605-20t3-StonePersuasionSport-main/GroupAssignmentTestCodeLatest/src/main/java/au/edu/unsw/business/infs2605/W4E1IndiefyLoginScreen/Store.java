/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

/**
 *
 * @author allyanatrajano
 */
public class Store {
    private String store_id;
    private String address;
    private String phone_number;
    private int store_manager;
    
    public Store(String store_id, String address, String phone_number, int store_manager) {
        this.store_id = store_id;
        this.address = address;
        this.phone_number = phone_number;
        this.store_manager = store_manager;    
    }

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public int getStore_manager() {
        return store_manager;
    }

    public void setStore_manager(int store_manager) {
        this.store_manager = store_manager;
    }
    
    
    
}
