/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

/**
 *
 * @author allyanatrajano
 */

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class UpdateStatusController implements Initializable {
    
Database database = new Database();
     
    @FXML
    ChoiceBox<String> orderStatus= new ChoiceBox<>();
    
    @FXML
    private Label orderIdLabel;
 

    //pull order_id from Supplier Dashboard Controller
    private String order_id;
    SupplierUser supplier_user;
    
    @FXML
    public void printOrderId(String order_id){
        orderIdLabel.setText(order_id);       
    }    

    public void initDataOrder(Orders orders){
        order_id = orders.getOrder_id();
    }
    public void initDataUser(SupplierUser user){
        supplier_user = user;
    } 
  
   
    //EDIT STATUS
    String orderstatus = (String)orderStatus.getValue(); 
    
    
    @FXML
    public void handleSaveButton(ActionEvent event)throws IOException, SQLException{ 
        database.editOrderStatus(order_id, orderStatus.getValue());
        database.addOrderUpdates(order_id, supplier_user.getUser_id());
     

        Node node = (Node)event.getSource();
        Stage stage = (Stage)node.getScene().getWindow();
        stage.fireEvent(new WindowEvent(stage, WindowEvent.WINDOW_CLOSE_REQUEST));   

    }      
   
    @FXML
    public void initialize(URL location, ResourceBundle resources) {
        orderStatus.getItems().addAll("Order Pending", "Order Packed", "Order Shipped", "Order Cancelled");
        orderStatus.getSelectionModel().select(0);    
        
    }    
     
    
}
