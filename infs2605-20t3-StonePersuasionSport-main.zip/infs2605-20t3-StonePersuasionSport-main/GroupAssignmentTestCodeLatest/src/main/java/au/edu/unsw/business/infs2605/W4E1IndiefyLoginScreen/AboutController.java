/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

/**
 *
 * @author allyanatrajano
 */
public class AboutController {

    @FXML
    public void initialize(){

    }    
    
    //CHANGE SCREENS
    @FXML
    private void handleNavigationCreateNewOrder(ActionEvent event) throws IOException {
        App.setRoot("CreateNewOrder");
    }
    
    @FXML
    private void handleNavigationOrderHistory(ActionEvent event) throws IOException {
        App.setRoot("OrderHistory");
    }   
        
    @FXML
    private void handleNavigationSupplier(ActionEvent event) throws IOException {
        App.setRoot("SupplierList");
    }  

    @FXML
    private void handleNavigationDashboard(ActionEvent event) throws IOException {
        App.setRoot("Dashboard");
    }   
    
    @FXML
    private void handleNavigationLogout(ActionEvent event) throws IOException {
        App.setRoot("LoginScreen");
    }         
    
}
