/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.W4E1IndiefyLoginScreen;

import java.lang.ClassNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import static java.sql.DriverManager.println;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.Timestamp;




/**
 *
 * @author YXTing
 */
public class Database {
    public void initialise() throws SQLException {
        //write the four lines which connect your program to the database
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        
        // create supplier
        String createSupplierQuery = "CREATE TABLE IF NOT EXISTS Supplier "
                + "("               
                + "SUPPLIER_ID INTEGER PRIMARY KEY autoincrement, "
                + "SUPPLIER_NAME TEXT NOT NULL, "
                + "PHONE_NUMBER INTEGER NOT NULL,"
                + "ADDRESS TEXT NOT NULL"
                + ");";
        st.execute(createSupplierQuery);
        System.out.println("Suppleir table created");
 
        String insertSupplier1 = "INSERT OR IGNORE INTO Supplier (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS) "
                          + "VALUES (300, 'Everyday Farm', 89896767, '4 North Drive SA 1234');";
        st.execute(insertSupplier1);
        String insertSupplier2 = "INSERT OR IGNORE INTO Supplier (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS) "
                          + "VALUES (301, 'Hello Bakery', 81234567, '5 South Avenue NT 4567');";
        st.execute(insertSupplier2);
        String insertSupplier3 = "INSERT OR IGNORE INTO Supplier (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS) "
                          + "VALUES (302, 'Pets World', 84321765, '6 West Street ACT 2468');";
        st.execute(insertSupplier3);      
        String insertSupplier4 = "INSERT OR IGNORE INTO Supplier (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS) "
                          + "VALUES (303, 'Fruit Factory', 85321735, '1 East Drive NSW 6789');";
        st.execute(insertSupplier4);
        String insertSupplier5 = "INSERT OR IGNORE INTO Supplier (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS) "
                          + "VALUES (304, 'Veggie Garden', 84324663, '2 Jelly Road TAS 6567');";
        st.execute(insertSupplier5);        
        String insertSupplier6 = "INSERT OR IGNORE INTO Supplier (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS) "
                          + "VALUES (305, 'Meat Warehouse', 84875765, '3 Starburst Court VIC 5555');";
        st.execute(insertSupplier6);          
        String insertSupplier7 = "INSERT OR IGNORE INTO Supplier (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS) "
                          + "VALUES (306, 'Woolies', 84621763, '6 Christmas Alley NSW 4444');";
        st.execute(insertSupplier7);         
        String insertSupplier8 = "INSERT OR IGNORE INTO Supplier (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS) "
                          + "VALUES (307, 'Coles', 89216759, '77 Beverley Hills NT 3333');";
        st.execute(insertSupplier8);
        String insertSupplier9 = "INSERT OR IGNORE INTO Supplier (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS) "
                          + "VALUES (308, 'Hunter Valley', 84355765, '68 Manhattan Road NSW 9898');";
        st.execute(insertSupplier9); 
        String insertSupplier10 = "INSERT OR IGNORE INTO Supplier (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS) "
                          + "VALUES (309, 'Chicken Shop', 84321662, '54 Brooklyn Avenue VIC 4354');";
        st.execute(insertSupplier10);        
        System.out.println("Supplier data successfully input");
        
        
        //create user
        String createUserQuery = "CREATE TABLE IF NOT EXISTS User "
                + "("
                + "USER_ID INTEGER PRIMARY KEY autoincrement, "
                + "USERNAME TEXT NOT NULL, "
                + "PASSWORD TEXT NOT NULL,"
                + "FULL_NAME TEXT NOT NULL,"
                + "USER_LEVEL TEXT NOT NULL"
                + ");";
        st.execute(createUserQuery);
        System.out.println("User Table Created");
       
        String insertUser1 = "INSERT OR IGNORE INTO User (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_LEVEL) "
                          + "VALUES (100, 'jsmith', 'monday', 'John Smith', 'Store');";
        st.execute(insertUser1);
        String insertUser2 = "INSERT OR IGNORE INTO User (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_LEVEL) "
                          + "VALUES (101, 'mjones', 'tuesday', 'Michelle Jones', 'Store');";
        st.execute(insertUser2);
        String insertUser3 = "INSERT OR IGNORE INTO User (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_LEVEL) "
                          + "VALUES (102, 'szhang', 'wednesday', 'Sarah Zhang', 'Supplier');";
        st.execute(insertUser3);     
        String insertUser4 = "INSERT OR IGNORE INTO User (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_LEVEL) "
                          + "VALUES (103, 'asprings', 'thursday', 'Alice Springs', 'Supplier');";
        st.execute(insertUser4); 
        String insertUser5 = "INSERT OR IGNORE INTO User (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_LEVEL) "
                          + "VALUES (104, 'bwilliams', 'friday', 'Barry Williams', 'Store');";
        st.execute(insertUser5); 
        String insertUser6 = "INSERT OR IGNORE INTO User (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_LEVEL) "
                          + "VALUES (105, 'cturner', 'saturday', 'Christian Turner', 'Store');";
        st.execute(insertUser6);         
        String insertUser7 = "INSERT OR IGNORE INTO User (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_LEVEL) "
                          + "VALUES (106, 'dwang', 'sunday', 'Danny Wang', 'Supplier');";
        st.execute(insertUser7);  
        String insertUser8 = "INSERT OR IGNORE INTO User (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_LEVEL) "
                          + "VALUES (107, 'echen', 'january', 'Ella Chen', 'Supplier');";
        String insertUser9 = "INSERT OR IGNORE INTO User (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_LEVEL) "
                          + "VALUES (108, 'fzhu', 'february', 'Fiona Zhu', 'Store');";
        st.execute(insertUser9);         
        String insertUser10 = "INSERT OR IGNORE INTO User (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_LEVEL) "
                          + "VALUES (109, 'gford', 'march', 'Greg Ford', 'Store');";
        st.execute(insertUser10);         
        
        
        System.out.println("User data successfully input");

        
        //create store_user
        String createStoreUserQuery = "CREATE TABLE IF NOT EXISTS Store_User"
                + "("
                + "USER_ID INTEGER PRIMARY KEY autoincrement, "
                + "FOREIGN KEY (USER_ID) REFERENCES User(USER_ID)"
                + ");";
        st.execute(createStoreUserQuery);

        String insertStoreUser1 = "INSERT OR IGNORE INTO Store_User (USER_ID) "
                          + "VALUES (100);";
        st.execute(insertStoreUser1);
        
        String insertStoreUser2 = "INSERT OR IGNORE INTO Store_User (USER_ID) "
                          + "VALUES (101);";
        st.execute(insertStoreUser2);
        String insertStoreUser3 = "INSERT OR IGNORE INTO Store_User (USER_ID) "
                          + "VALUES (104);";
        st.execute(insertStoreUser3);
        String insertStoreUser4 = "INSERT OR IGNORE INTO Store_User (USER_ID) "
                          + "VALUES (105);";
        st.execute(insertStoreUser4);  
        String insertStoreUser5 = "INSERT OR IGNORE INTO Store_User (USER_ID) "
                          + "VALUES (108);";
        st.execute(insertStoreUser5);   
        String insertStoreUser6 = "INSERT OR IGNORE INTO Store_User (USER_ID) "
                          + "VALUES (109);";
        st.execute(insertStoreUser6);           
        System.out.println("Store_User data successfully input");       
      
        
        // create supplier_user
        String createSupplierUserQuery = "CREATE TABLE IF NOT EXISTS Supplier_User"
                + "("
                + "USER_ID INTEGER PRIMARY KEY autoincrement, "
                + "SUPPLIER_ID INTEGER NOT NULL,"
                + "FOREIGN KEY (USER_ID) REFERENCES User(USER_ID),"
                + "FOREIGN KEY (SUPPLIER_ID) REFERENCES Supplier(SUPPLIER_ID)"
                + ");";
        st.execute(createSupplierUserQuery);
        
        String insertSupplierUser1 = "INSERT OR IGNORE INTO Supplier_User (USER_ID, SUPPLIER_ID) "
                          + "VALUES (102, 302);";
        st.execute(insertSupplierUser1);
        String insertSupplierUser2 = "INSERT OR IGNORE INTO Supplier_User (USER_ID, SUPPLIER_ID) "
                          + "VALUES (103, 303);";
        st.execute(insertSupplierUser2);   
        String insertSupplierUser3 = "INSERT OR IGNORE INTO Supplier_User (USER_ID, SUPPLIER_ID) "
                          + "VALUES (106, 306);";
        st.execute(insertSupplierUser3);     
        String insertSupplierUser4 = "INSERT OR IGNORE INTO Supplier_User (USER_ID, SUPPLIER_ID) "
                          + "VALUES (107, 307);";
        st.execute(insertSupplierUser4);        
        System.out.println("Supplier_User data successfully input");

        
        System.out.println("Supplier_User data successfully input");
        
        
        String createStoreQuery = "CREATE TABLE IF NOT EXISTS Store "
                + "("               
                + "STORE_ID INTEGER PRIMARY KEY autoincrement, "
                + "ADDRESS TEXT NOT NULL, "
                + "PHONE_NUMBER INTEGER NOT NULL,"
                + "STORE_MANAGER INTEGER NOT NULL,"
                + "FOREIGN KEY (STORE_MANAGER) REFERENCES User(USER_ID)"
                + ");";
        st.execute(createStoreQuery);  
        System.out.println("Store table created");
 
        String insertStore1 = "INSERT OR IGNORE INTO Store (STORE_ID, ADDRESS, PHONE_NUMBER, STORE_MANAGER) "
                          + "VALUES (200, '1 Test Road NSW 1000', 98761234, 100);";
        st.execute(insertStore1);
        String insertStore2 = "INSERT OR IGNORE INTO Store (STORE_ID, ADDRESS, PHONE_NUMBER, STORE_MANAGER) "
                          + "VALUES (201, '2 Sample Avenue VIC 2000', 98987676, 101);";
        st.execute(insertStore2);
        String insertStore3 = "INSERT OR IGNORE INTO Store (STORE_ID, ADDRESS, PHONE_NUMBER, STORE_MANAGER) "
                          + "VALUES (202, '3 Random Street WA 3000', 91234567, 102);";
        st.execute(insertStore3);
        System.out.println("Store data successfully input");

        //create product
        String createProductQuery = "CREATE TABLE IF NOT EXISTS Product "
                + "("               
                + "PRODUCT_ID INTEGER PRIMARY KEY autoincrement, "
                + "PRODUCT_NAME TEXT NOT NULL, "
                + "PRICE REAL NOT NULL,"
                + "PRODUCT_TYPE TEXT NULL"
                + ");";
        st.execute(createProductQuery);
        System.out.println("Product table created");        
 
        String insertProduct1 = "INSERT OR IGNORE INTO Product (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
                          + "VALUES (500, 'Royal Gala Apple', 2, 'Fresh Fruits');";
        st.execute(insertProduct1);
        String insertProduct2 = "INSERT OR IGNORE INTO Product (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
                          + "VALUES (501, 'Chocolate Croissant', 4, 'Baked Goods');";
        st.execute(insertProduct2);
        String insertProduct3 = "INSERT OR IGNORE INTO Product (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
                          + "VALUES (502, 'Happy Dog Food', 10, 'Pet Supplies');";
        st.execute(insertProduct3);
        String insertProduct4 = "INSERT OR IGNORE INTO Product (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
                          + "VALUES (503, 'Laundry Detergent', 6, 'Cleaning');";
        st.execute(insertProduct4);  
        String insertProduct5 = "INSERT OR IGNORE INTO Product (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
                          + "VALUES (504, 'Lemon Squares', 8, 'Baked Goods');";
        st.execute(insertProduct5);    
        String insertProduct6 = "INSERT OR IGNORE INTO Product (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
                          + "VALUES (505, 'Green Grapes', 10, 'Fresh Fruits');";
        st.execute(insertProduct6);
        String insertProduct7 = "INSERT OR IGNORE INTO Product (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
                          + "VALUES (506, 'Arnotts Biscuits', 12, 'Snacks');";
        st.execute(insertProduct7);  
        String insertProduct8 = "INSERT OR IGNORE INTO Product (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
                          + "VALUES (507, 'Coco Pops', 14, 'Breakfast');";
        st.execute(insertProduct8);  
        String insertProduct9 = "INSERT OR IGNORE INTO Product (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
                          + "VALUES (508, 'Cat Food', 16, 'Pet Supplies');";
        st.execute(insertProduct9); 
        String insertProduct10 = "INSERT OR IGNORE INTO Product (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
                          + "VALUES (509, 'Pure Orange', 5, 'Drinks');";
        st.execute(insertProduct10);         
        System.out.println("Product data successfully input");
        
        //create orders       
        String createOrdersQuery = "CREATE TABLE IF NOT EXISTS Orders "
                + "("               
                + "ORDER_ID INTEGER PRIMARY KEY autoincrement, "
                + "SUPPLIER_ID INTEGER NOT NULL,"
                + "STATUS TEXT DEFAULT 'Order Placed' NOT NULL,"
                + "ORDER_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,"
                + "FOREIGN KEY (SUPPLIER_ID) REFERENCES Supplier(SUPPLIER_ID)"
                + ");";
        st.execute(createOrdersQuery);
        System.out.println("Orders table created");        
        
        String insertOrder1 = "INSERT OR IGNORE INTO Orders (ORDER_ID, SUPPLIER_ID, STATUS, ORDER_TIMESTAMP) "
                          + "VALUES (400, 300, 'Order Placed', '2020-10-30 16:30:00');";
        st.execute(insertOrder1);
        String insertOrder2 = "INSERT OR IGNORE INTO Orders (ORDER_ID, SUPPLIER_ID, STATUS, ORDER_TIMESTAMP) "
                          + "VALUES (401, 301, 'Order Placed', '2020-10-25 08:30:00');";
        st.execute(insertOrder2);
        String insertOrder3 = "INSERT OR IGNORE INTO Orders (ORDER_ID, SUPPLIER_ID, STATUS, ORDER_TIMESTAMP) "
                          + "VALUES (402, 302, 'Order Placed', '2020-11-1 15:00:00');";
        st.execute(insertOrder3);      
        String insertOrder4 = "INSERT OR IGNORE INTO Orders (ORDER_ID, SUPPLIER_ID, STATUS, ORDER_TIMESTAMP) "
                          + "VALUES (403, 302, 'Order Placed', '2020-11-12 15:30:00');";
        st.execute(insertOrder4);          
        String insertOrder5 = "INSERT OR IGNORE INTO Orders (ORDER_ID, SUPPLIER_ID, STATUS, ORDER_TIMESTAMP) "
                          + "VALUES (404, 302, 'Order Placed', '2020-10-12 15:30:00');";
        st.execute(insertOrder5);           
        String insertOrder6 = "INSERT OR IGNORE INTO Orders (ORDER_ID, SUPPLIER_ID, STATUS, ORDER_TIMESTAMP) "
                          + "VALUES (405, 302, 'Order Placed', '2020-7-12 15:30:00');";
        st.execute(insertOrder6);
        String insertOrder7 = "INSERT OR IGNORE INTO Orders (ORDER_ID, SUPPLIER_ID, STATUS, ORDER_TIMESTAMP) "
                          + "VALUES (406, 303, 'Order Placed', '2020-10-18 14:45:00');";
        st.execute(insertOrder7);         
        String insertOrder8 = "INSERT OR IGNORE INTO Orders (ORDER_ID, SUPPLIER_ID, STATUS, ORDER_TIMESTAMP) "
                          + "VALUES (407, 303, 'Order Placed', '2020-11-12 19:30:00');";
        st.execute(insertOrder8);        
        String insertOrder9 = "INSERT OR IGNORE INTO Orders (ORDER_ID, SUPPLIER_ID, STATUS, ORDER_TIMESTAMP) "
                          + "VALUES (408, 306, 'Order Placed', '2020-8-12 21:30:00');";
        st.execute(insertOrder9); 
        String insertOrder10 = "INSERT OR IGNORE INTO Orders (ORDER_ID, SUPPLIER_ID, STATUS, ORDER_TIMESTAMP) "
                          + "VALUES (409, 306, 'Order Placed', '2020-11-2 13:30:00');";
        st.execute(insertOrder10);        
        System.out.println("Order data successfully input");
        
        //order_detail table creation
        
        String createOrderDetailQuery = "CREATE TABLE IF NOT EXISTS Order_Details "
                + "("               
                + "ORDER_ID INTEGER NOT NULL, "
                + "PRODUCT_ID INTEGER NOT NULL,"
                + "QUANTITY INTEGER NOT NULL,"
                + "PRIMARY KEY (ORDER_ID, PRODUCT_ID),"
                + "FOREIGN KEY (PRODUCT_ID) REFERENCES Product(PRODUCT_ID),"
                + "FOREIGN KEY (ORDER_ID) REFERENCES Orders(ORDER_ID)"
                + ");";
        st.execute(createOrderDetailQuery);
        System.out.println("Order Details table created");          

        String insertOrderDetails1 = "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES (400, 500, 10);";
        st.execute(insertOrderDetails1);        
        
        String insertOrderDetails2 = "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES (401, 501, 20);";
        st.execute(insertOrderDetails2);   
        
        String insertOrderDetails3 = "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES (402, 502, 30);";
        st.execute(insertOrderDetails3);  
        String insertOrderDetails4 = "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES (403, 503, 40);";
        st.execute(insertOrderDetails4);          
        String insertOrderDetails5 = "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES (404, 504, 10);";
        st.execute(insertOrderDetails5);          
        String insertOrderDetails6 = "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES (405, 505, 10);";
        st.execute(insertOrderDetails6); 
        String insertOrderDetails7 = "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES (406, 506, 10);";
        st.execute(insertOrderDetails7); 
        String insertOrderDetails8 = "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES (407, 507, 10);";
        st.execute(insertOrderDetails8);                
        String insertOrderDetails9 = "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES (408, 508, 10);";
        st.execute(insertOrderDetails9);          
        String insertOrderDetails10= "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES (409, 509, 10);";
        st.execute(insertOrderDetails10);  
        String insertOrderDetails11= "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES (409, 500, 10);";
        st.execute(insertOrderDetails11);         
        String insertOrderDetails12= "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES (409, 501, 10);";
        st.execute(insertOrderDetails12);         
        
        System.out.println("Order Details data successfully input");
    
        //Create Order_Updates table
        String createOrderUpdateQuery = "CREATE TABLE IF NOT EXISTS Order_Updates "
                + "("
                + "USER_ID INTEGER NOT NULL,"
                + "ORDER_ID INTEGER NOT NULL,"
                + "UPDATE_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,"
               // + "UPDATE_TIMESTAMP TIMESTAMP DEFAULT (strftime('%Y-%m-%dT%H:%M','now', 'localtime'))," 
                //+ "UPDATE_TIMESTAMP TIMESTAMP DEFAULT ((strftime('%s','now'), 'unixepoch', 'localtime')),"
                // + "UPDATE_TIMESTAMP TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M','now', 'localtime')), "             
                + "PRIMARY KEY (USER_ID, ORDER_ID, UPDATE_TIMESTAMP),"
                + "FOREIGN KEY (USER_ID) REFERENCES Supplier_User(USER_ID),"
                + "FOREIGN KEY (ORDER_ID) REFERENCES Orders(ORDER_ID)"
                + ");";
        
        
        st.execute(createOrderUpdateQuery);
        System.out.println("Order Updates table created"); 
        
       
        st.close();
        conn.close();        
        
    }
    
    //LOG IN
    public boolean login(String username, String password, String userlevel) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        if (userlevel.equals("Store Login")){
            String query1 = "SELECT * FROM User INNER JOIN Store_User ON User.USER_ID = Store_User.USER_ID WHERE USERNAME = '" + username + "' AND PASSWORD = '" + password + "'";
            System.out.println(query1);
            ResultSet rs = st.executeQuery(query1);
            if (rs.next()) {
                st.close();
                conn.close();
                return true;
            } else {
                st.close();
                conn.close();
                return false;
            }
        }
        else{
            String query2 = "SELECT * FROM User INNER JOIN Supplier_User ON User.USER_ID = Supplier_User.USER_ID WHERE USERNAME = '" + username + "' AND PASSWORD = '" + password + "'";
            ResultSet rs = st.executeQuery(query2);
            if (rs.next()) {
                st.close();
                conn.close();
                return true;
            } else {
                st.close();
                conn.close();
                return false;
            }
            
        }
        
    }
    
    
    //Create new Orders
    public void addOrder(String supplier_id) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String addOrderQuery = "INSERT OR IGNORE INTO Orders (SUPPLIER_ID) "
                          + "VALUES ('" + supplier_id + "');";
        st.execute(addOrderQuery);  
        st.close();
        conn.close();
    }
    
    //Get latest Order_Id from Orders table
    public String getOrder_id()throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String getLatestOrder_id = "SELECT * FROM ORDERS WHERE ORDER_ID = (SELECT MAX(ORDER_ID)  FROM ORDERS)";
        ResultSet rs = st.executeQuery(getLatestOrder_id);
        
        String returnOrderId =  rs.getString("ORDER_ID");
        
        st.close();
        conn.close();      
       
        return returnOrderId;
    }
    
    //Add Products and Quantity to Order
    public void addToOrderDetails(String order_id,String product_id, int quantity) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String addOrderDetailsQuery = "INSERT OR IGNORE INTO Order_Details (ORDER_ID, PRODUCT_ID, QUANTITY) "
                          + "VALUES ('" + order_id + "','" + product_id + "', '" + quantity + "');";   
        st.execute(addOrderDetailsQuery);
        st.close();
        conn.close();
    }
    
    //Update existing Orders
    public void editOrderProduct_id(String order_id, String product_id) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String editOrderProduct_idQuery = "UPDATE Order_Details SET PRODUCT_ID = '"+product_id+"' WHERE ORDER_ID = '"+order_id+"'";
        st.execute(editOrderProduct_idQuery);  
        st.close();
        conn.close();
    }     
   
    //edit order qunatity 
    public void editOrderQuantity (String order_id, String quantity)throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String editOrderQuantity_idQuery = "UPDATE Order_Details SET QUANTITY = '"+quantity+"' WHERE ORDER_ID = '"+order_id+"'";
        st.execute(editOrderQuantity_idQuery);  
        st.close();
        conn.close();       
    }
    
    
    //Delete Product from OrderDetails
    public void deleteOrderDetails(String product_id) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String deleteOrderQuery = "DELETE FROM Order_Details WHERE PRODUCT_ID = '"+product_id+"'";
        st.execute(deleteOrderQuery);   
        st.close();
        conn.close();        
    }      
    
    //Print Orders for Debugging purposes
    public void printOrder() throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();    
        String getOrderQuery = "SELECT * FROM Orders INNER JOIN Order_Details ON Orders.ORDER_ID = Order_Details.ORDER_ID";
        ResultSet rs = st.executeQuery(getOrderQuery);
        while (rs.next()) {
            System.out.println(rs.getString("ORDER_ID")+ " " + rs.getString("PRODUCT_ID") + " " +  rs.getString("SUPPLIER_ID")+ " " + rs.getString("QUANTITY") + " " + rs.getString("STATUS") + " " + rs.getString("ORDER_TIMESTAMP"));
        }
        st.close();
        conn.close();
    }
    
    //TABLE VIEW ORDER
    public ObservableList<Orders> getOrders() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String query = "SELECT * FROM Orders";
        ResultSet rs = st.executeQuery(query);
        ObservableList<Orders> ordersList = FXCollections.observableArrayList();
        while (rs.next()) {
            ordersList.add(new Orders(rs.getString("ORDER_ID"), rs.getString("SUPPLIER_ID"), rs.getString("STATUS"), rs.getString("ORDER_TIMESTAMP")));
        }
        st.close();
        conn.close();
        return ordersList;
    }      
   
    //TABLE VIEW ORDER DETAILS OF ADDITIONAL PRODUCTS
    public ObservableList<DisplayProduct> getOrderDetails(String order_id) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String query = "SELECT * FROM Order_Details INNER JOIN Product ON Order_Details.PRODUCT_ID = Product.PRODUCT_ID WHERE ORDER_ID = '" + order_id+ "'";
        ResultSet rs = st.executeQuery(query);
        ObservableList<DisplayProduct> orderDetailsList = FXCollections.observableArrayList();
        while (rs.next()) {
            orderDetailsList.add(new DisplayProduct(rs.getString("ORDER_ID"), rs.getString("PRODUCT_ID"), rs.getString("PRODUCT_NAME"), rs.getString("QUANTITY")));
        }
        st.close();
        conn.close();
        return orderDetailsList;
    } 

    
    
    //Update existing Orders
    public void editOrderHistoryProduct_id(String order_id, String product_id) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String editOrderProduct_idQuery = "UPDATE Orders SET PRODUCT_ID = '"+product_id+"' WHERE ORDER_ID = '"+order_id+"'";
        st.execute(editOrderProduct_idQuery); 
        
        st.close();
        conn.close();        
    } 
    
    
    //edit Order History
    public void editOrderHistorySupplier_id(String order_id, String supplier_id) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String editOrderSupplier_idQuery = "UPDATE Orders SET SUPPLIER_ID = '"+supplier_id+"' WHERE ORDER_ID = '"+order_id+"'";
        st.execute(editOrderSupplier_idQuery);  
        
        st.close();
        conn.close();        
    }  
    
//edit order history quantity
    public void editOrderHistoryQuantity(String order_id, String quantity) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String editOrderQuantityQuery = "UPDATE Orders SET QUANTITY = '"+quantity+"' WHERE ORDER_ID = '"+order_id+"'";
        st.execute(editOrderQuantityQuery); 
        
        st.close();
        conn.close();       
    } 
    
    //Delete Orders from Database
    public void deleteOrders(String order_id) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String deleteOrderQuery = "DELETE FROM Orders WHERE ORDER_ID = '"+order_id+"'";
        st.execute(deleteOrderQuery); 
        
        st.close();
        conn.close();        
    }    
    
    
    
    //Add new Supplier
    public void addSupplier(String name, String phone_number, String address) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String addSupplierQuery = "INSERT OR IGNORE INTO Supplier (SUPPLIER_NAME, PHONE_NUMBER, ADDRESS) "
                          + "VALUES ('" + name + "', '" + phone_number + "', '" + address + "');";
        st.execute(addSupplierQuery); 
        st.close();
        conn.close();
    }
    
    //Edit Existing Supplier
    public void editSupplierName(String supplier_id, String supplier_name) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String editSupplierNameQuery = "UPDATE Supplier SET SUPPLIER_NAME = '"+supplier_name+"' WHERE SUPPLIER_ID = '"+supplier_id+"'";
        st.execute(editSupplierNameQuery);
        st.close();
        conn.close();
    }
    
    //edit supplier  phone number 
    public void editSupplierPhoneNumber(String supplier_id, String phone_number) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String editSupplierPhoneNumberQuery = "UPDATE Supplier SET PHONE_NUMBER = '"+phone_number+"' WHERE SUPPLIER_ID = '"+supplier_id+"'";
        st.execute(editSupplierPhoneNumberQuery);
        st.close();
        conn.close();
    }
    
    public void editSupplierAddress(String supplier_id, String address) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String editSupplierAddressQuery = "UPDATE Supplier SET ADDRESS = '"+address+"' WHERE SUPPLIER_ID = '"+supplier_id+"'";
        st.execute(editSupplierAddressQuery);   
        st.close();
        conn.close();
    }
    
    //Delete Supplier from Database
    public void deleteSupplier(String supplier_id) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String deleteSupplierQuery = "DELETE FROM Supplier WHERE SUPPLIER_ID = '"+supplier_id+"'";
        st.execute(deleteSupplierQuery);   
        st.close();
        conn.close();
    } 
    
  
    
    //Print Supplier for Debugging purposes
    public void printSupplier() throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();    
        String getSupplierQuery = "SELECT SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS FROM Supplier";
        ResultSet rs = st.executeQuery(getSupplierQuery);
        while (rs.next()) {
            System.out.println(rs.getString("SUPPLIER_ID")+ " " + rs.getString("SUPPLIER_NAME") + " " +  rs.getString("PHONE_NUMBER")+ " " + rs.getString("ADDRESS"));
        }
        st.close();
        conn.close();
    }    
    
    // Oberservable List of suppliers
    public ObservableList<Supplier> getSupplier() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String query = "SELECT SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS FROM Supplier";
        ResultSet rs = st.executeQuery(query);
        ObservableList<Supplier> supplierList = FXCollections.observableArrayList();
        while (rs.next()) {
            supplierList.add(new Supplier (rs.getString("SUPPLIER_ID"), rs.getString("SUPPLIER_NAME"), rs.getString("PHONE_NUMBER"), rs.getString("ADDRESS")));
        }
        st.close();
        conn.close();
        return supplierList;
    }    

    
    //TABLE VIEW ORDER UPDATES
    public ObservableList<OrderUpdates> getOrderUpdates() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String query = "SELECT * FROM Order_Updates INNER JOIN User ON Order_Updates.USER_ID = User.USER_ID";
        ResultSet rs = st.executeQuery(query);
        ObservableList<OrderUpdates> ordersList = FXCollections.observableArrayList();
        while (rs.next()) {
            ordersList.add(new OrderUpdates(rs.getString("ORDER_ID"), rs.getString("USER_ID"), rs.getString("UPDATE_TIMESTAMP"), rs.getString("FULL_NAME")));
        }
        st.close();
        conn.close();
        return ordersList;
    } 
    
    //get User ID from User Name
    public String getUserId(String username) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String getUserId = "SELECT * FROM User WHERE USERNAME = '"+username+"'";
        ResultSet rs = st.executeQuery(getUserId);
        
        String returnUserId =  rs.getString("USER_ID");
        
        st.close();
        conn.close();      
       
        return returnUserId;       
    }
    
    // get Supplier ID from User ID
    public String getSupplierId(String userId)throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String getSupplierId = "SELECT * FROM Supplier_User WHERE USER_ID = '"+userId+"'";
        ResultSet rs = st.executeQuery(getSupplierId);
        
        String returnSupplierId =  rs.getString("SUPPLIER_ID");
        
        st.close();
        conn.close();      
       
        return returnSupplierId;         
        
    }
    
    //Get Supplier ID from Username
    public String getSupplierIdFromUsername(String username)throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String getSupplierId = "SELECT * FROM User INNER JOIN Supplier_User ON User.USER_ID = Supplier_User.USER_ID WHERE USERNAME = '" + username + "' " ;
        ResultSet rs = st.executeQuery(getSupplierId);
        
        String returnSupplierId =  rs.getString("SUPPLIER_ID");
        
        st.close();
        conn.close();      
       
        return returnSupplierId;         
        
    }       
    
    //Get Supplier Name from Username
    public String getSupplierNameFromUsername(String username)throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String getSupplierId = "SELECT * FROM User INNER JOIN Supplier_User ON User.USER_ID = Supplier_User.USER_ID INNER JOIN Supplier ON Supplier_User.SUPPLIER_ID = Supplier.SUPPLIER_ID WHERE USERNAME = '" + username + "' " ;
        ResultSet rs = st.executeQuery(getSupplierId);
        
        String returnSupplierId =  rs.getString("SUPPLIER_NAME");
        
        st.close();
        conn.close();      
       
        return returnSupplierId;         
        
    }     
    
    //TABLE VIEW ORDER SUPPLIER LOGIN
    public ObservableList<Orders> getOrdersSupplier(String supplier_id) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String query = "SELECT * FROM Orders WHERE SUPPLIER_ID = '" + supplier_id + "'";
        ResultSet rs = st.executeQuery(query);
        ObservableList<Orders> ordersList = FXCollections.observableArrayList();
        while (rs.next()) {
            ordersList.add(new Orders(rs.getString("ORDER_ID"), rs.getString("SUPPLIER_ID"), rs.getString("STATUS"), rs.getString("ORDER_TIMESTAMP")));
        }
        st.close();
        conn.close();
        return ordersList;
    }      
    
    //Update Status existing Orders in Supplier Dashboard
    public void editOrderStatus(String order_id, String status) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String editOrderStatusQuery = "UPDATE Orders SET STATUS = '"+status+"' WHERE ORDER_ID = '"+order_id+"'";
        st.execute(editOrderStatusQuery);  
        st.close();
        conn.close();
    }  
    
    //Update Order Updates
    public void addOrderUpdates(String order_id, String user_id) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();        
        String editOrderUpdatesQuery = "INSERT OR IGNORE INTO Order_Updates (ORDER_ID, USER_ID) "
                          + "VALUES ('" + order_id + "','" + user_id + "');";   
        st.execute(editOrderUpdatesQuery);  
        st.close();
        conn.close();
    }   
    
    //TABLE VIEW ORDER DETAILS FOR DASHBOARD
    public ObservableList<DisplayOrder> getOrderDisplay() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String query = "SELECT * FROM Orders INNER JOIN Order_Details ON Orders.ORDER_ID = Order_Details.ORDER_ID INNER JOIN Product ON Order_Details.PRODUCT_ID = Product.PRODUCT_ID";
        ResultSet rs = st.executeQuery(query);
        ObservableList<DisplayOrder> orderDisplayList = FXCollections.observableArrayList();
        while (rs.next()) {
            orderDisplayList.add(new DisplayOrder(rs.getString("ORDER_ID"),rs.getString("PRODUCT_NAME"), rs.getString("QUANTITY"),rs.getString("STATUS")));
        }
        st.close();
        conn.close();
        return orderDisplayList;
    }  
    
    
    //DEBUGGING
    public void printDisplayOrder() throws SQLException {  
    Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String query = "SELECT * FROM Orders INNER JOIN Order_Details ON Orders.ORDER_ID = Order_Details.ORDER_ID INNER JOIN Product ON Order_Details.PRODUCT_ID = Product.PRODUCT_ID";
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            System.out.println(rs.getString("ORDER_ID") + rs.getString("PRODUCT_NAME") + rs.getString("QUANTITY") + rs.getString("STATUS"));
        }
        st.close();
        conn.close();
        
    } 
    
   
    //PIECHART DATABASE 
     public static ResultSet getResultSet(String query) throws SQLException {
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
       
        try{
        conn = DriverManager.getConnection("jdbc:sqlite:database.db"); 
        st = conn.createStatement();
        rs = st.executeQuery(query);
        
        return rs;      
        }
        catch (Exception e) {
           e.printStackTrace();
           System.out.println("closed");
           st.close();
           conn.close();  
        
        } 
        st.close();
        conn.close();
        System.out.println("closed");
        return rs;   
        }
     
     
     
    
     //TABLE VIEW PRODUCT
    public ObservableList<Product> getProduct() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st = conn.createStatement();
        String query = "SELECT * FROM Product";
        ResultSet rs = st.executeQuery(query);
        ObservableList<Product> productList = FXCollections.observableArrayList();
        while (rs.next()) {
            productList.add(new Product(rs.getString("PRODUCT_ID"), rs.getString("PRODUCT_NAME"), rs.getInt("PRICE"), rs.getString("PRODUCT_TYPE")));
        }
        st.close();
        conn.close();
        return productList;    
    } 
    
    
     
}



    
   
